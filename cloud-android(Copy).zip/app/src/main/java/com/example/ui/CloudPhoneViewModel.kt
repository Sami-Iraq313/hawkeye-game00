package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CloudPhoneEntity
import com.example.data.CloudPhoneRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class UserSession(
    val uid: String,
    val email: String,
    val displayName: String?,
    val isAnonymous: Boolean = false,
    val token: String? = null
)

class CloudPhoneViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CloudPhoneRepository
    
    // Language Preference persistence
    private val sharedPrefs = application.getSharedPreferences("aether_prefs", android.content.Context.MODE_PRIVATE)
    private val _isArabic = MutableStateFlow(sharedPrefs.getBoolean("is_arabic", true))
    val isArabic: StateFlow<Boolean> = _isArabic.asStateFlow()

    fun setLanguage(arabic: Boolean) {
        _isArabic.value = arabic
        sharedPrefs.edit().putBoolean("is_arabic", arabic).apply()
        logPlatformEvent("Language", "System language changed to: ${if (arabic) "Arabic" else "English"}")
    }
    
    // User session state
    private val _currentUser = MutableStateFlow<UserSession?>(null)
    val currentUser: StateFlow<UserSession?> = _currentUser.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allPhones: StateFlow<List<CloudPhoneEntity>> = _currentUser
        .flatMapLatest { user ->
            if (user == null) {
                flowOf(emptyList())
            } else {
                repository.getPhonesByUser(user.uid)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selected Cloud Phone ID for remote screen visualization
    private val _selectedPhoneId = MutableStateFlow<Int?>(null)
    val selectedPhoneId: StateFlow<Int?> = _selectedPhoneId.asStateFlow()

    // Virtual console logs for the platform hypervisor
    private val _platformLogs = MutableStateFlow<List<String>>(emptyList())
    val platformLogs: StateFlow<List<String>> = _platformLogs.asStateFlow()

    // Interactive screen screen state
    private val _activeScreenState = MutableStateFlow("Launcher") // "Launcher", "Browser", "AppStore", "Terminal", "Settings"
    val activeScreenState: StateFlow<String> = _activeScreenState.asStateFlow()

    // Live terminal input/output inside the virtual phone
    private val _phoneTerminalHistory = MutableStateFlow<List<String>>(listOf("CloudPhone-OS v3.5-KVM init...", "Welcome to isolated bash. Type 'help' or commands."))
    val phoneTerminalHistory: StateFlow<List<String>> = _phoneTerminalHistory.asStateFlow()

    // Job for dynamic stats updates
    private var statsJob: Job? = null

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CloudPhoneRepository(database.cloudPhoneDao())

        // Auto-initialize standard system virtualization logs
        viewModelScope.launch {
            logPlatformEvent("Hypervisor", "Host virtualization node initialized successfully. CPU: Dual AMD EPYC 9654, RAM: 512GB ECC DDR5, GPU: NVIDIA L40S GRID vGPU cluster.")
            logPlatformEvent("ZFS Storage", "Thin-provisioned storage pool zpool-vphone online. 4.2TB / 12.0TB used.")
            logPlatformEvent("GMS License", "GMS Android Compatibility Test Suite (CTS) profiles registered. License server responsive.")
            logPlatformEvent("Security", "Zero-Trust Cryptographic Core active. Sandboxing rules applied.")
        }

        startRealtimeStatsSimulation()
    }

    // Attempt Firebase initialisation check
    fun isFirebaseAvailable(): Boolean {
        return try {
            com.google.firebase.FirebaseApp.getInstance()
            true
        } catch (e: Exception) {
            false
        }
    }

    // Set secure isolated user session
    fun selectUser(session: UserSession) {
        viewModelScope.launch {
            _currentUser.value = session
            repository.populateDefaultDataIfEmpty(session.uid)
            delay(300)
            // Auto-select first device for the user if available
            val userPhones = repository.getPhonesByUser(session.uid).first()
            _selectedPhoneId.value = userPhones.firstOrNull()?.id
            logPlatformEvent("Security", "Session fully isolated and active for UID: ${session.uid}")
        }
    }

    // Logout and purge session memory keys
    fun logout() {
        _currentUser.value = null
        _selectedPhoneId.value = null
        logPlatformEvent("Security", "User session terminated cleanly. Ephemeral encryption keys purged.")
    }

    private fun startRealtimeStatsSimulation() {
        statsJob?.cancel()
        statsJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                val currentList = allPhones.value
                for (phone in currentList) {
                    if (phone.status == "RUNNING") {
                        // Slightly jitter the metrics to look live
                        val cpuDelta = (Random.nextFloat() * 10f) - 5f
                        val ramDelta = (Random.nextFloat() * 6f) - 3f
                        val updatedCpu = (phone.systemLoadCpu + cpuDelta).coerceIn(2f, 98f)
                        val updatedRam = (phone.systemLoadRam + ramDelta).coerceIn(5f, 95f)
                        
                        repository.updatePhone(
                            phone.copy(
                                systemLoadCpu = updatedCpu,
                                systemLoadRam = updatedRam
                            )
                        )
                    }
                }
            }
        }
    }

    // Platform Logs logger helper
    fun logPlatformEvent(subsystem: String, message: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val formatted = "[$timestamp] [$subsystem] $message"
        _platformLogs.value = (listOf(formatted) + _platformLogs.value).take(100)
    }

    // Device Management operations
    fun selectPhone(id: Int) {
        _selectedPhoneId.value = id
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: repository.getPhoneById(id)
            phone?.let {
                val nextScreen = if (it.activeApp == "System Launcher" || it.activeApp.isEmpty()) "Launcher" else it.activeApp
                _activeScreenState.value = nextScreen
                repository.updatePhone(it.copy(lastOpenedTime = System.currentTimeMillis()))
            }
        }
    }

    fun setPhoneScreenState(screen: String) {
        _activeScreenState.value = screen
        val selected = allPhones.value.find { it.id == selectedPhoneId.value }
        if (selected != null) {
            viewModelScope.launch {
                repository.updatePhone(selected.copy(activeApp = screen))
            }
            logPlatformEvent("RemoteControl", "Selected Phone '${selected.name}' screen transitioned to: $screen")
        }
    }

    fun provisionNewPhone(
        name: String,
        androidVersion: String,
        cpuCores: Int,
        ramGb: Int,
        storageGb: Int,
        networkProfile: String,
        userProfile: String,
        gmsLicensed: Boolean
    ) {
        viewModelScope.launch {
            val uid = _currentUser.value?.uid ?: "default_user"
            logPlatformEvent("Hypervisor", "Queued new instance provision request: '$name' ($androidVersion, ${cpuCores} vCPUs, ${ramGb}GB RAM)")
            logPlatformEvent("Storage", "Allocating thin-provisioned 1:1 image overlay for $name (${storageGb}GB virtual block)")
            repository.provisionPhone(uid, name, androidVersion, cpuCores, ramGb, storageGb, networkProfile, userProfile, gmsLicensed)
            delay(100)
            logPlatformEvent("Network", "IP assigned dynamically for '$name'. Initializing bridge routing protocol.")
        }
    }

    fun clonePhone(sourceId: Int, destinationName: String) {
        viewModelScope.launch {
            val source = allPhones.value.find { it.id == sourceId } ?: return@launch
            logPlatformEvent("Hypervisor", "Cloning instance '${source.name}' (ID: $sourceId) into '$destinationName'")
            logPlatformEvent("Storage", "Creating COW (Copy-On-Write) snapshot: zpool-vphone/instance-$sourceId@snap")
            repository.clonePhone(sourceId, destinationName)
            logPlatformEvent("Storage", "COW Snapshot clone completed for '$destinationName'. Deploying container configuration.")
        }
    }

    fun renamePhone(id: Int, newName: String) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: repository.getPhoneById(id)
            phone?.let {
                repository.updatePhone(it.copy(name = newName))
                logPlatformEvent("Hypervisor", "Renamed instance '${it.name}' to '$newName'")
            }
        }
    }

    fun restartPhone(id: Int) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: return@launch
            logPlatformEvent("Hypervisor", "Sending ACPI hard reset command to instance '${phone.name}'")
            repository.restartPhone(id)
            logPlatformEvent("Hypervisor", "Instance '${phone.name}' came back online.")
        }
    }

    fun backupPhone(id: Int) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: return@launch
            logPlatformEvent("ZFS Storage", "Starting incremental snapshot transfer for '${phone.name}' data volume")
            repository.backupPhone(id)
            logPlatformEvent("BackupServer", "Successfully verified block checksums for '${phone.name}' in remote replication vault.")
        }
    }

    fun stopPhone(id: Int) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: return@launch
            logPlatformEvent("Hypervisor", "Sending SIGTERM to container services in '${phone.name}'")
            repository.stopPhone(id)
            logPlatformEvent("Hypervisor", "Instance '${phone.name}' stopped and resources unmapped from KVM scheduler.")
        }
    }

    fun startPhone(id: Int) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: return@launch
            logPlatformEvent("Hypervisor", "Launching container scheduler for '${phone.name}'")
            repository.startPhone(id)
            logPlatformEvent("Hypervisor", "Instance '${phone.name}' status set to RUNNING. VNC/WebRTC port bound.")
        }
    }

    fun deletePhone(id: Int) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == id } ?: return@launch
            logPlatformEvent("Hypervisor", "Deallocating virtual storage and config paths for '${phone.name}'")
            repository.deletePhoneById(id)
            if (_selectedPhoneId.value == id) {
                // Default to first remaining
                _selectedPhoneId.value = allPhones.value.firstOrNull()?.id
            }
            logPlatformEvent("Storage", "Storage block paths successfully trimmed and reclaimed for '${phone.name}'")
        }
    }

    fun installAppForPhone(phoneId: Int, appName: String) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == phoneId } ?: return@launch
            val currentApps = phone.installedAppsRaw.split(";").filter { it.isNotEmpty() }.toMutableList()
            if (!currentApps.contains(appName)) {
                currentApps.add(appName)
                val updatedApps = currentApps.joinToString(";")
                repository.updatePhone(phone.copy(installedAppsRaw = updatedApps))
                logPlatformEvent("AppManager", "Verified APK signature. Extracted and isolated '$appName' under secure sandbox-instance-${phone.id}")
            }
        }
    }

    fun addAccountForPhone(phoneId: Int, appName: String, accountName: String, proxy: String) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == phoneId } ?: return@launch
            val currentAccounts = phone.accountsRaw.split(";").filter { it.isNotEmpty() }.toMutableList()
            val newRecord = "$appName:$accountName:$proxy"
            currentAccounts.add(newRecord)
            val updatedAccounts = currentAccounts.joinToString(";")
            repository.updatePhone(phone.copy(accountsRaw = updatedAccounts))
            logPlatformEvent("AccountManager", "Secure container workspace initialized for $appName ($accountName) routed via $proxy. Fingerprint randomisation applied successfully.")
        }
    }

    fun removeAccountForPhone(phoneId: Int, appName: String, accountName: String) {
        viewModelScope.launch {
            val phone = allPhones.value.find { it.id == phoneId } ?: return@launch
            val currentAccounts = phone.accountsRaw.split(";").filter { it.isNotEmpty() }.toMutableList()
            currentAccounts.removeAll { it.startsWith("$appName:$accountName:") }
            val updatedAccounts = currentAccounts.joinToString(";")
            repository.updatePhone(phone.copy(accountsRaw = updatedAccounts))
            logPlatformEvent("AccountManager", "Terminated session workspace for $appName ($accountName). Ephemeral credentials securely shredded.")
        }
    }

    // Phone Virtual Terminal commands handler
    fun executePhoneTerminalCommand(cmdString: String) {
        val trimmed = cmdString.trim()
        if (trimmed.isEmpty()) return
        
        val history = _phoneTerminalHistory.value.toMutableList()
        history.add("$ root@cloud-phone:~$ $trimmed")
        
        val response = when (trimmed.lowercase()) {
            "help" -> listOf(
                "Available commands:",
                "  help          - Display this assistance list",
                "  uname -a      - Show virtual linux kernel environment",
                "  df -h         - Check isolated ext4 storage partitions",
                "  top -n 1      - Fetch active process load",
                "  ifconfig      - Display simulated virtual eth0 layout",
                "  getprop gms   - Inspect GMS framework compliance info",
                "  clear         - Wipe session terminal console"
            )
            "uname -a" -> {
                val selected = allPhones.value.find { it.id == selectedPhoneId.value }
                listOf("Linux cloud-vphone-node 6.1.0-android14-common-g9ea48 #1 SMP PREEMPT KVM ARM64")
            }
            "df -h" -> {
                val selected = allPhones.value.find { it.id == selectedPhoneId.value }
                val size = selected?.storageGb ?: 64
                listOf(
                    "Filesystem      Size  Used Avail Use% Mounted on",
                    "/dev/block/vd0   12G  7.4G  4.1G  65% /system",
                    "/dev/block/vd1  ${size}G  1.2G  ${size - 2}G   5% /data",
                    "tmpfs           2.0G  420K  2.0G   1% /dev"
                )
            }
            "top -n 1" -> listOf(
                "PID USER         PR  NI CPU% S  #THR     VSZ     RSS PCY Name",
                "2351 system       20   0   4% S    68 284520K  98212K  fg com.android.systemui",
                "2982 radio        20   0   1% S    22  98124K  34120K  bg com.android.phone",
                "3510 root         20   0   2% R     1   9520K   3120K  fg top"
            )
            "ifconfig" -> {
                val selected = allPhones.value.find { it.id == selectedPhoneId.value }
                val ip = selected?.ipAddress ?: "10.0.2.15"
                listOf(
                    "eth0      Link encap:Ethernet  HWaddr DE:AD:BE:EF:00:11",
                    "          inet addr:$ip  Bcast:10.255.255.255  Mask:255.255.0.0",
                    "          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1",
                    "          RX packets:2401 errors:0 dropped:0 overruns:0 frame:0",
                    "          TX packets:1984 errors:0 dropped:0 overruns:0 carrier:0"
                )
            }
            "getprop gms" -> {
                val selected = allPhones.value.find { it.id == selectedPhoneId.value }
                val licensed = selected?.gmsLicensed ?: true
                if (licensed) {
                    listOf(
                        "ro.com.google.gmsversion = 24.12.17",
                        "ro.com.google.clientidbase = android-google",
                        "ro.build.fingerprint = google/coral/coral:13/TP1A.220905.004/8927542:user/release-keys",
                        "STATUS: GMS Play Integrity / SafetyNet Verified (PASS)"
                    )
                } else {
                    listOf(
                        "ro.com.google.gmsversion = null (Disabled)",
                        "ro.com.google.clientidbase = null",
                        "ro.build.fingerprint = custom/open-vphone/vphone:14/TP1A/user-debug",
                        "STATUS: GMS Bypass Mode / MicroG emulation (UNSUPPORTED / RESTRICTED)"
                    )
                }
            }
            "clear" -> {
                _phoneTerminalHistory.value = listOf("Terminal cleared.")
                return
            }
            else -> listOf("bash: $trimmed: command not found")
        }
        
        history.addAll(response)
        _phoneTerminalHistory.value = history.takeLast(150)
    }

    override fun onCleared() {
        super.onCleared()
        statsJob?.cancel()
    }
}
