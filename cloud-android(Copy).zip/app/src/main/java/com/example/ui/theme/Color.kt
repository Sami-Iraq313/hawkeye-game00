package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Slate Dark palette
val SlateDarkBackground = Color(0xFF0F172A) // Slate 900
val SlateDarkSurface = Color(0xFF1E293B) // Slate 800
val SlateDarkBorder = Color(0xFF334155) // Slate 700

// Professional Polish Theme Colors
val BluePrimary = Color(0xFF2563EB) // Enterprise Blue (blue-600)
val IndigoSecondary = Color(0xFF4F46E5) // Indigo (indigo-600)
val EmeraldSuccess = Color(0xFF10B981) // Emerald (emerald-500)
val AmberWarning = Color(0xFFF59E0B) // Amber (amber-500)
val RoseError = Color(0xFFEF4444) // Red (red-500)

// Aliases for seamless compilation & uniform theme alignment
val CyanPrimary = BluePrimary
val BlueSecondary = IndigoSecondary

val TerminalGreen = Color(0xFF22C55E) // Green for isolated shells
val TerminalBlack = Color(0xFF020617) // Deep slate black

// Soft Slate Light background from theme spec HTML ("bg-[#F3F4F9]")
val SlateLightBackground = Color(0xFFF3F4F9) 
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightBorder = Color(0xFFE2E8F0) // Slate 200
val SlateLightBorderAccent = Color(0xFFDBEAFE) // Blue 100 for polished cards
