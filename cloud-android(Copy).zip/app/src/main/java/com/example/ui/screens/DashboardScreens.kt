package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CloudPhoneEntity
import com.example.ui.CloudPhoneViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

enum class DashboardTab(val title: String, val icon: ImageVector) {
    PHONES("Phones", Icons.Default.PhoneAndroid),
    REMOTE("Remote Control", Icons.Default.CastConnected),
    INFRASTRUCTURE("Infrastructure", Icons.Default.Dns),
    SECURITY_VPN("Security & VPN", Icons.Default.VpnLock)
}

@Composable
fun l(english: String, isArabic: Boolean): String {
    if (!isArabic) return english
    return when (english) {
        "AetherCloud" -> "إيثر كلاود"
        "ENTERPRISE ARCH" -> "البنية المؤسسية"
        "Cluster Health:" -> "صحة المجموعة:"
        "Normal" -> "طبيعي"
        "Region: US-EAST-1" -> "المنطقة: US-EAST-1"
        "vCPU Load" -> "حمل المعالج"
        "RAM Util" -> "استهلاك الرام"
        "GPU Accel" -> "معالج الرسوميات"
        "Cloud Virtualization Cluster" -> "عنقود الأجهزة الافتراضية"
        "Active Devices" -> "الأجهزة النشطة"
        "Provision Instance" -> "إنشاء جهاز جديد"
        "Search cloud devices..." -> "البحث في الأجهزة السحابية..."
        "IP Address" -> "عنوان IP"
        "Active App" -> "التطبيق النشط"
        "Network profile" -> "ملف الشبكة"
        "Storage" -> "مساحة التخزين"
        "Cores" -> "الأنوية"
        "GMS CTS Status" -> "حالة ترخيص GMS CTS"
        "LICENSED" -> "مرخص"
        "UNLICENSED" -> "غير مرخص"
        "Action Gateway" -> "بوابة الإجراءات"
        "Interactive Remote Stream" -> "البث التفاعلي عن بعد"
        "Reboot Node" -> "إعادة تشغيل"
        "Snapshot Backup" -> "نسخة احتياطية"
        "Clone Virtual Device" -> "نسخ متطابق"
        "Power Off Node" -> "إيقاف التشغيل"
        "Power On Node" -> "تشغيل الجهاز"
        "Decommission Node" -> "حذف وإلغاء الجهاز"
        "Terminate Cloud Phone?" -> "هل تريد إنهاء الجهاز السحابي؟"
        "Decommission Instance" -> "تفكيك وإلغاء الجهاز"
        "Cancel" -> "إلغاء الأمر"
        "Configure New Virtual Device" -> "تكوين جهاز افتراضي جديد"
        "Device Name" -> "اسم الجهاز"
        "Android Version" -> "إصدار أندرويد"
        "vCPU Cores" -> "أنوية vCPU"
        "RAM Allocation" -> "تخصيص الرام"
        "Virtual Storage Size" -> "حجم التخزين الافتراضي"
        "Network Simulation Profile" -> "ملف محاكاة الشبكة"
        "Virtual User Profile" -> "ملف تعريف المستخدم"
        "Google Mobile Services (GMS) License" -> "ترخيص خدمات جوجل (GMS)"
        "Register CTS Device Profile" -> "تسجيل جهاز متوافق CTS"
        "Provision Device Node" -> "بدء تهيئة الجهاز"
        "Clone Virtual Instance" -> "استنساخ الجهاز الافتراضي"
        "Target Instance Name" -> "اسم الجهاز المستهدف"
        "Clone Instance" -> "استنساخ الجهاز"
        "GMS Legal" -> "مرخص GMS"
        "CPU Usage" -> "استهلاك المعالج"
        "Offline" -> "غير متصل"
        "QUICK SCREEN SHORTCUTS" -> "اختصارات الشاشة السريعة"
        "VIRTUAL PHONE BUTTONS" -> "أزرار الهاتف الافتراضية"
        "HOST COMMAND INJECTOR" -> "حاقن أوامر المضيف"
        "Directly pipe shell commands into the virtual Android container hypervisor layer." -> "حقن أوامر الطرفية مباشرة في طبقة نظام تشغيل حاوية أندرويد الافتراضية."
        "e.g. uname -a, top -n 1, getprop gms" -> "مثال: uname -a, top -n 1, getprop gms"
        "Back" -> "رجوع"
        "Home" -> "الرئيسية"
        "Kill VM" -> "إنهاء الجهاز الافتراضي"
        "Launcher" -> "المشغّل"
        "Browser" -> "المتصفح"
        "AppStore" -> "متجر التطبيقات"
        "Terminal" -> "الطرفية"
        "Settings" -> "الإعدادات"
        "PLATFORM METRICS & ARCHITECTURE" -> "مقاييس المنصة والبنية التحتية"
        "Enterprise Node Bandwidth (Simulated Live)" -> "عرض نطاق عقدة المؤسسة (محاكاة مباشرة)"
        "Inbound: 2.45 Gbps" -> "التنزيل: 2.45 جيجابت/ث"
        "Outbound: 4.82 Gbps" -> "الرفع: 4.82 جيجابت/ث"
        "Total Connections: 1,420" -> "إجمالي الاتصالات: 1,420"
        "HYPERVISOR HOST EVENT LOGS" -> "سجلات أحداث مضيف مفرط الافتراضية"
        "CLOUD ARCHITECTURE SPECIFICATION" -> "مواصفات البنية السحابية"
        "1. Virtualization Technology Stack" -> "1. حزمة تقنيات الافتراضية"
        "2. GMS (Google Mobile Services) Licensing & Compliance" -> "2. تراخيص خدمات جوجل (GMS) والامتثال"
        "3. Security & Multi-User Isolation" -> "3. الأمان وعزل المستخدمين المتعددين"
        "4. Open-Source Self-Hosted Pricing Model" -> "4. نموذج التسعير الذاتي مفتوح المصدر"
        "5. Roadmap (MVP to Enterprise Scale)" -> "5. خارطة الطريق (من النسخة التجريبية إلى نطاق المؤسسات)"
        "Manage professional anti-intrusion, anti-fingerprinting, and anti-ban systems." -> "إدارة أنظمة منع الاختراق وتغيير البصمة ومكافحة حظر الحسابات الاحترافية."
        "A+ MAXIMUM SECURITY STATE" -> "حالة الحماية القصوى A+"
        "Enforces mandatory access control and sandboxes isolated container runtimes." -> "يفرض التحكم الإلزامي في الوصول ويعزل بيئات تشغيل الحاويات المستقلة."
        "Defends virtual device runtimes against memory injection, overflow, and hijack attacks." -> "يحمي بيئات تشغيل الأجهزة الافتراضية ضد هجمات حقن الذاكرة، والتجاوز، والاختطاف."
        "Spoofs IMEI, MAC addresses, Android IDs, and build parameters to block fingerprint-based tracking." -> "يزيف أرقام IMEI، وعناوين MAC، ومعرفات Android، ومعلمات البناء لمنع تتبع البصمة الرقمية."
        "Disconnects camera sensors and microphone modules. Feeds blank loops to apps." -> "يفصل مستشعرات الكاميرا ووحدات الميكروفون برمجياً، ويغذي التطبيقات ببيانات فارغة."
        "Routes each instance through residential IP subnets, avoiding datacenter-based account bans." -> "يمرر كل جهاز عبر شبكات بروكسي سكنية لتجنب حظر الحسابات الناتج عن مراكز البيانات."
        "Bypasses SafetyNet/CTS checks to run financial and banking apps securely without detection." -> "يتجاوز فحوصات SafetyNet/CTS لتشغيل التطبيقات المالية والبنكية بأمان دون اكتشاف."
        "Locks physical GPS coords with matching residential IP location to prevent telemetry discrepancies." -> "يثبت إحداثيات الموقع الجغرافي لتتطابق مع موقع عنوان IP السكني لتجنب أي تعارض."
        "Clear Logs" -> "مسح السجلات"
        "Phones" -> "الأجهزة"
        "Remote Control" -> "التحكم عن بعد"
        "Infrastructure" -> "البنية التحتية"
        "Security & VPN" -> "الأمان والشبكة"
        "Active Stream:" -> "البث النشط:"
        "No Active Stream" -> "لا يوجد بث نشط"
        "Please select a cloud phone from the Devices tab to initialize the secure remote stream viewport." -> "يرجى اختيار جهاز سحابي من علامة تبويب الأجهزة لبدء البث الآمن عن بعد."
        "SYSTEM METRICS" -> "مقاييس النظام"
        "CPU Load" -> "حمل المعالج"
        "RAM Usage" -> "استخدام الرام"
        "FPS Rate" -> "معدل الإطارات"
        "Network Latency" -> "تأخير الشبكة"
        "Interactive Sandbox Shortcuts" -> "اختصارات بيئة التجربة التفاعلية"
        "Home Button" -> "الرئيسية"
        "Back Gesture" -> "الرجوع"
        "App Switcher" -> "مبدل التطبيقات"
        "Virtual Hardware Control Center" -> "مركز التحكم بالعتاد الافتراضي"
        "Rotate Device" -> "تدوير الشاشة"
        "Volume Up" -> "رفع الصوت"
        "Volume Down" -> "خفض الصوت"
        "Simulate GPS Location Change" -> "محاكاة موقع GPS"
        "Power Cycle Device" -> "إعادة تشغيل عتادية"
        "Virtual Storage Block Expander" -> "توسيع وحدة التخزين"
        "Trigger Safe Mode" -> "تفعيل الوضع الآمن"
        "Simulate Device Shake" -> "هز الجهاز"
        "Hardware Sandbox Sensor Console" -> "وحدة حساسات البيئة المعزولة"
        "Terminal Commands Dashboard" -> "لوحة تحكم أوامر الطرفية"
        "Execute Command" -> "تنفيذ الأمر"
        "Send Keyboard Raw Event" -> "إرسال حدث لوحة المفاتيح"
        "Open System Settings" -> "فتح إعدادات النظام"
        "App Store Gateway" -> "بوابة متجر التطبيقات"
        "Google Chrome" -> "جوجل كروم"
        "System Launcher" -> "مشغل النظام الرئيسي"
        "Terminal Console" -> "محرر الطرفية Bash"
        "Virtual Settings" -> "الإعدادات الافتراضية"
        "Hypervisor Log stream" -> "بث سجلات مدير الأجهزة الافتراضية"
        "Clear Console History" -> "مسح سجل الأوامر"
        "Reset Terminal" -> "إعادة تعيين الطرفية"
        "Installed Secure Applications" -> "التطبيقات الآمنة المثبتة"
        "Install Sandbox Apps" -> "تثبيت تطبيقات البيئة المعزولة"
        "WhatsApp (Sandbox)" -> "واتساب المعزول"
        "Instagram (Simulated)" -> "إنستغرام المحاكى"
        "Telegram Secure Tunnel" -> "تيليجرام آمن النفق"
        "Install" -> "تثبيت"
        "INSTALLED" -> "مثبت بالفعل"
        "Search Google Play" -> "البحث في Google Play"
        "Close" -> "إغلاق"
        "Hypervisor Host Status" -> "حالة مضيف Hypervisor"
        "Active Node Nodes" -> "الأجهزة السحابية النشطة"
        "CPU Core Capacity" -> "سعة أنوية المعالجات vCPU"
        "Total Virtual Block Storage" -> "إجمالي تخزين الكتل الافتراضية"
        "Storage IOPS" -> "عمليات إدخال/إخراج التخزين (IOPS)"
        "Zero-Trust Security Shield" -> "درع الأمان بنظام الثقة المعدومة"
        "Security & Encryption Matrix" -> "مصفوفة الأمان والتشفير"
        "VPN Tunnel Configuration" -> "تكوين نفق VPN المشفر"
        "Bypass Protection" -> "تجاوز الحماية"
        "IP Rotation Engine" -> "محرك تدوير عناوين IP"
        "Device Sandbox Isolation Profile" -> "ملف عزل بيئة الأجهزة"
        "Enterprise Gateway Shield" -> "درع بوابة المؤسسة الآمنة"
        "Log Out" -> "تسجيل الخروج"
        "Zero-Trust Active" -> "الثقة المعدومة نشطة"
        "Normal Security Profile" -> "ملف الأمان العادي"
        "High Security Isolation" -> "عزل أمني عالي الدقة"
        "Military Grade Encryption" -> "تشفير بمستوى عسكري"
        "Anti-Tracking" -> "منع التعقب"
        "Secure" -> "آمن ومحمي"
        "Host" -> "المضيف"
        "Instance" -> "الجهاز السحابي"
        "Virtual" -> "افتراضي"
        "Virtual Device Network Gateway" -> "بوابة شبكة الأجهزة الافتراضية"
        "Virtual Private Network status" -> "حالة الشبكة الافتراضية الخاصة VPN"
        "Proxy & WireGuard Status" -> "حالة البروكسي و WireGuard"
        "Active WireGuard Tunnel" -> "نفق WireGuard النشط"
        "Total Data Transferred" -> "إجمالي البيانات المنقولة"
        "Rotate IP" -> "تدوير عنوان IP"
        "System Log Console" -> "سجل أحداث النظام المشفر"
        "Search Logs..." -> "البحث في السجلات..."
        "Clear Logs" -> "مسح السجلات"
        "No events matched search query." -> "لا توجد أحداث مطابقة للبحث."
        "Virtual Machine Details" -> "تفاصيل الجهاز الافتراضي"
        "Hardware Config" -> "تكوين العتاد"
        "Network Latency Simulation" -> "محاكاة تأخير الشبكة"
        "Virtual Sensors Simulator" -> "محاكي الحساسات الافتراضية"
        "Log Stream Dashboard" -> "لوحة سجلات الأجهزة"
        "Isolated Instances" -> "الأجهزة المعزولة"
        "Deploy New" -> "نشر جديد"
        "GPU Usage" -> "استخدام المعالج"
        "RAM Allocated" -> "الرام المخصص"
        "HYPERVISOR POWER DESK" -> "لوحة طاقة مفرط الافتراضية"
        "Stop" -> "إيقاف"
        "Stopping..." -> "جاري الإيقاف..."
        "Starting..." -> "جاري التشغيل..."
        "Start" -> "تشغيل"
        "Restarting..." -> "جاري إعادة التشغيل..."
        "Restart" -> "إعادة تشغيل"
        "Cloning..." -> "جاري النسخ..."
        "Clone" -> "نسخ"
        "Connect" -> "اتصال"
        "Backup" -> "نسخة احتياطية"
        else -> english
    }
}

fun getTabTitle(tab: DashboardTab, isArabic: Boolean): String {
    return when (tab) {
        DashboardTab.PHONES -> if (isArabic) "الأجهزة" else "Phones"
        DashboardTab.REMOTE -> if (isArabic) "التحكم عن بعد" else "Remote Control"
        DashboardTab.INFRASTRUCTURE -> if (isArabic) "البنية التحتية" else "Infrastructure"
        DashboardTab.SECURITY_VPN -> if (isArabic) "الأمان والشبكة" else "Security & VPN"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardContainer(viewModel: CloudPhoneViewModel) {
    val phones by viewModel.allPhones.collectAsState()
    val selectedPhoneId by viewModel.selectedPhoneId.collectAsState()
    val selectedPhone = phones.find { it.id == selectedPhoneId }
    
    var currentTab by remember { mutableStateOf(DashboardTab.PHONES) }
    var showProvisionDialog by remember { mutableStateOf(false) }
    var showCloneDialog by remember { mutableStateOf<CloudPhoneEntity?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<CloudPhoneEntity?>(null) }
    var showRenameDialog by remember { mutableStateOf<CloudPhoneEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Professional Polish Logo Box: 40dp x 40dp, rounded-xl, deep blue background, shadow
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .shadow(
                                        elevation = 6.dp,
                                        shape = RoundedCornerShape(12.dp),
                                        ambientColor = BluePrimary.copy(alpha = 0.5f),
                                        spotColor = BluePrimary.copy(alpha = 0.5f)
                                    )
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(BluePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Dns,
                                    contentDescription = "Enterprise Cluster",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "AetherCloud",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        letterSpacing = (-0.2).sp
                                    )
                                )
                                Text(
                                    text = "ENTERPRISE ARCH",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = BluePrimary,
                                        fontSize = 9.sp,
                                        letterSpacing = 1.2.sp
                                    )
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        // Notifications Button
                        IconButton(
                            onClick = {
                                viewModel.logPlatformEvent("Dashboard", "Checked notification desk: 0 pending critical events.")
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .border(1.dp, SlateLightBorder, CircleShape)
                                .background(Color.White, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        val isArabicState by viewModel.isArabic.collectAsState()

                        // Bilingual Language Switcher Button
                        IconButton(
                            onClick = {
                                viewModel.setLanguage(!isArabicState)
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .border(1.dp, SlateLightBorder, CircleShape)
                                .background(Color.White, CircleShape)
                                .testTag("dashboard_language_switcher")
                        ) {
                            Text(
                                text = if (isArabicState) "EN" else "AR",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BluePrimary
                                )
                            )
                        }

                        val currentUserState by viewModel.currentUser.collectAsState()

                        // Display user nickname
                        Text(
                            text = currentUserState?.displayName ?: "",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                            ),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        // Logout sign out button (Bilingual representation)
                        IconButton(
                            onClick = {
                                viewModel.logout()
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .border(1.dp, RoseError.copy(alpha = 0.2f), CircleShape)
                                .background(Color(0xFFFEF2F2), CircleShape)
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Log Out",
                                tint = RoseError,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            val isArabicState by viewModel.isArabic.collectAsState()
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                DashboardTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(getTabTitle(tab, isArabicState), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        val isArabicState by viewModel.isArabic.collectAsState()
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(250)) togetherWith fadeOut(animationSpec = tween(200))
                },
                label = "TabTransition"
            ) { targetTab ->
                when (targetTab) {
                    DashboardTab.PHONES -> {
                        PhonesTab(
                            phones = phones,
                            selectedPhoneId = selectedPhoneId,
                            isArabic = isArabicState,
                            onProvisionClick = { showProvisionDialog = true },
                            onSelectForRemote = { id ->
                                viewModel.selectPhone(id)
                                currentTab = DashboardTab.REMOTE
                            },
                            onRestart = { id -> viewModel.restartPhone(id) },
                            onBackup = { id -> viewModel.backupPhone(id) },
                            onClone = { phone -> showCloneDialog = phone },
                            onStop = { id -> viewModel.stopPhone(id) },
                            onStart = { id -> viewModel.startPhone(id) },
                            onDelete = { phone -> showDeleteConfirmDialog = phone },
                            onRename = { phone -> showRenameDialog = phone }
                        )
                    }
                    DashboardTab.REMOTE -> {
                        RemoteControlTab(
                            viewModel = viewModel,
                            selectedPhone = selectedPhone,
                            allPhones = phones,
                            isArabic = isArabicState
                        )
                    }
                    DashboardTab.INFRASTRUCTURE -> {
                        InfrastructureTab(viewModel = viewModel, isArabic = isArabicState)
                    }
                    DashboardTab.SECURITY_VPN -> {
                        SecurityVpnTab(viewModel = viewModel, isArabic = isArabicState)
                    }
                }
            }
        }
    }

    val isArabicState by viewModel.isArabic.collectAsState()

    // Provision New Instance Dialog
    if (showProvisionDialog) {
        ProvisionDialog(
            isArabic = isArabicState,
            onDismiss = { showProvisionDialog = false },
            onConfirm = { name, version, cpu, ram, storage, network, profile, gms ->
                viewModel.provisionNewPhone(name, version, cpu, ram, storage, network, profile, gms)
                showProvisionDialog = false
            }
        )
    }

    // Clone Existing Instance Dialog
    showCloneDialog?.let { sourcePhone ->
        CloneDialog(
            sourcePhone = sourcePhone,
            isArabic = isArabicState,
            onDismiss = { showCloneDialog = null },
            onConfirm = { destName ->
                viewModel.clonePhone(sourcePhone.id, destName)
                showCloneDialog = null
            }
        )
    }

    // Delete Confirmation Dialog
    showDeleteConfirmDialog?.let { phone ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text(l("Terminate Cloud Phone?", isArabicState)) },
            text = { 
                Text(
                    if (isArabicState) 
                        "سيؤدي هذا إلى حذف الجهاز السحابي '${phone.name}' (IP: ${phone.ipAddress}) نهائياً. سيتم إتلاف جميع وحدات التخزين المحلية وملفات البيئة المعزولة والتكوينات بالكامل. لا يمكن التراجع عن هذا الإجراء."
                    else 
                        "This will permanently delete the virtual instance '${phone.name}' (IP: ${phone.ipAddress}). All local storage blocks, sandbox files, and configurations will be unmapped and shredded. This cannot be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deletePhone(phone.id)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = RoseError),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text(l("Decommission Instance", isArabicState))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text(l("Cancel", isArabicState))
                }
            }
        )
    }

    // Rename Instance Dialog
    showRenameDialog?.let { phone ->
        var tempName by remember { mutableStateOf(phone.name) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = null },
            title = {
                Text(
                    text = if (isArabicState) "تعديل اسم الجهاز" else "Rename Cloud Phone",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isArabicState) "أدخل الاسم الجديد للجهاز السحابي:" else "Enter the new name for the cloud phone:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = tempName,
                        onValueChange = { tempName = it },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_rename_name"),
                        label = { Text(if (isArabicState) "الاسم الجديد" else "New Name") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tempName.isNotBlank()) {
                            viewModel.renamePhone(phone.id, tempName.trim())
                            showRenameDialog = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    modifier = Modifier.testTag("confirm_rename_button")
                ) {
                    Text(if (isArabicState) "حفظ" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = null }) {
                    Text(if (isArabicState) "إلغاء" else "Cancel")
                }
            }
        )
    }
}

@Composable
fun PhonesTab(
    phones: List<CloudPhoneEntity>,
    selectedPhoneId: Int? = null,
    isArabic: Boolean,
    onProvisionClick: () -> Unit,
    onSelectForRemote: (Int) -> Unit,
    onRestart: (Int) -> Unit,
    onBackup: (Int) -> Unit,
    onClone: (CloudPhoneEntity) -> Unit,
    onStop: (Int) -> Unit,
    onStart: (Int) -> Unit,
    onDelete: (CloudPhoneEntity) -> Unit,
    onRename: (CloudPhoneEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Infrastructure Health Summary (Professional Polish Theme)
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Top Status Banner Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = l("Cluster Health:", isArabic),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF64748B) // Slate 500
                            )
                        )
                        Text(
                            text = l("Normal", isArabic),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                        )
                    }
 
                    // Region Mono Badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF1F5F9), // Slate 100
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        Text(
                            text = if (isArabic) "المنطقة: US-EAST-1" else "Region: US-EAST-1",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569) // Slate 600
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
 
                // 3-Column Metrics Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val runningCount = phones.count { it.status == "RUNNING" }
                    val cpuUsage = (runningCount * 12.5f + 10f).coerceAtMost(95f)
                    val ramUsage = (runningCount * 8.0f + 15f).coerceAtMost(90f)
                    val gpuUsage = (runningCount * 4.0f + 4f).coerceAtMost(80f)
 
                    // Col 1: vCPU Load
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = l("vCPU Load", isArabic),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF94A3B8), // Slate 400
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${String.format("%.0f", cpuUsage)}%",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A) // Slate 900
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(bottom = 6.dp)
                                    .height(6.dp)
                                    .background(Color(0xFFF1F5F9), CircleShape)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = (cpuUsage / 100f).coerceIn(0.01f, 1f))
                                        .background(BluePrimary, CircleShape)
                                )
                            }
                        }
                    }
 
                    // Col 2: RAM Util
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = l("RAM Util", isArabic),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF94A3B8), // Slate 400
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${String.format("%.0f", ramUsage)}%",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A) // Slate 900
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(bottom = 6.dp)
                                    .height(6.dp)
                                    .background(Color(0xFFF1F5F9), CircleShape)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = (ramUsage / 100f).coerceIn(0.01f, 1f))
                                        .background(IndigoSecondary, CircleShape)
                                )
                            }
                        }
                    }
 
                    // Col 3: GPU Accel
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = l("GPU Accel", isArabic),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF94A3B8), // Slate 400
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "${String.format("%.0f", gpuUsage)}%",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A) // Slate 900
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(bottom = 6.dp)
                                    .height(6.dp)
                                    .background(Color(0xFFF1F5F9), CircleShape)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = (gpuUsage / 100f).coerceIn(0.01f, 1f))
                                        .background(AmberWarning, CircleShape)
                                )
                            }
                        }
                    }
                }
            }
        }
 
        // Isolated Instances Header Row (Professional Polish Theme)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = l("Isolated Instances", isArabic),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B) // Slate 800
                    )
                )
                Text(
                    text = if (isArabic) "يتم حفظ الأجهزة تلقائياً وترتيبها حسب النشاط للعودة السريعة" else "Devices are saved and sorted by activity for quick return",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF64748B),
                        fontSize = 11.sp
                    )
                )
            }
            
            TextButton(
                onClick = onProvisionClick,
                colors = ButtonDefaults.textButtonColors(contentColor = BluePrimary),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.testTag("provision_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription = "Deploy",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = l("Deploy New", isArabic),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
 
        if (phones.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "No phones",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                    )
                    Text(l("No Cloud Phones online.", isArabic))
                    TextButton(onClick = onProvisionClick) {
                        Text(l("Create your first Cloud Phone", isArabic))
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(phones, key = { it.id }) { phone ->
                    CloudPhoneCard(
                        phone = phone,
                        isSelected = phone.id == selectedPhoneId,
                        isArabic = isArabic,
                        onSelectForRemote = onSelectForRemote,
                        onRestart = onRestart,
                        onBackup = onBackup,
                        onClone = onClone,
                        onStop = onStop,
                        onStart = onStart,
                        onDelete = onDelete,
                        onRename = onRename
                    )
                }
            }
        }
 
        // Quick Stats Overlay (Security Policy) (Professional Polish Theme)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFFE3E7F1))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color.White, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Security Status",
                        tint = BluePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = l("SECURITY POLICY", isArabic),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B) // Slate 500
                        )
                    )
                    Text(
                        text = if (isArabic) "تم تفعيل مستوى العزل 4" else "Isolation Level 4 Enabled",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B) // Slate 800
                        )
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = Color(0xFF94A3B8) // Slate 400
            )
        }
    }
}

@Composable
fun CloudPhoneCard(
    phone: CloudPhoneEntity,
    isSelected: Boolean = false,
    isArabic: Boolean,
    onSelectForRemote: (Int) -> Unit,
    onRestart: (Int) -> Unit,
    onBackup: (Int) -> Unit,
    onClone: (CloudPhoneEntity) -> Unit,
    onStop: (Int) -> Unit,
    onStart: (Int) -> Unit,
    onDelete: (CloudPhoneEntity) -> Unit,
    onRename: (CloudPhoneEntity) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cloud_phone_card_${phone.id}")
            .clickable { onSelectForRemote(phone.id) },
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) BluePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val coroutineScope = rememberCoroutineScope()
            var localStarting by remember(phone.id) { mutableStateOf(false) }
            var localStopping by remember(phone.id) { mutableStateOf(false) }
            var localRestarting by remember(phone.id) { mutableStateOf(false) }

            // Title & Status Badge Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = if (phone.status == "RUNNING") CyanPrimary else Color.Gray,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = phone.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            IconButton(
                                onClick = { onRename(phone) },
                                modifier = Modifier
                                    .size(20.dp)
                                    .testTag("rename_phone_button_${phone.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Rename",
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            if (isSelected) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = BluePrimary.copy(alpha = 0.15f),
                                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.4f))
                                ) {
                                    Text(
                                        text = if (isArabic) "نشط" else "Active",
                                        color = BluePrimary,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "IP: ${phone.ipAddress} | ${phone.androidVersion}",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        )
                    }
                }

                // Dynamic Status Chip
                StatusChip(status = phone.status, isArabic = isArabic)
            }

            // Specs Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpecChip(icon = Icons.Default.DeveloperMode, text = "${phone.cpuCores} vCPU")
                SpecChip(icon = Icons.Default.Settings, text = "${phone.ramGb} GB RAM")
                SpecChip(icon = Icons.Default.Storage, text = "${phone.storageGb} GB SSD")
                
                if (phone.gmsLicensed) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = l("GMS Legal", isArabic),
                            color = EmeraldSuccess,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Live Performance metrics (CPU / RAM of container)
            if (phone.status == "RUNNING") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(l("CPU Usage", isArabic), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("${String.format("%.1f", phone.systemLoadCpu)}%", style = MaterialTheme.typography.labelSmall, color = CyanPrimary)
                        }
                        LinearProgressIndicator(
                            progress = { phone.systemLoadCpu / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = CyanPrimary,
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                        )
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(l("RAM Allocated", isArabic), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("${String.format("%.1f", phone.systemLoadRam)}%", style = MaterialTheme.typography.labelSmall, color = BlueSecondary)
                        }
                        LinearProgressIndicator(
                            progress = { phone.systemLoadRam / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = BlueSecondary,
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

            // Professional Polish Control Panel UI Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF8FAFC)) // Slate 50
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp)) // Slate 200
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val isRunning = phone.status == "RUNNING"
                    val isStopped = phone.status == "STOPPED"
                    val isRestartingStatus = phone.status == "RESTARTING"

                    // Control Panel Label Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = l("HYPERVISOR POWER DESK", isArabic),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF475569), // Slate 600
                                    letterSpacing = 0.8.sp
                                )
                            )
                        }
                        
                        // Delete/Decommission action
                        IconButton(
                            onClick = { onDelete(phone) },
                            modifier = Modifier.size(24.dp).testTag("delete_phone_${phone.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Terminate Instance",
                                tint = RoseError.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    
                    // Button row 1: Start/Stop & Restart
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        
                        // START / STOP ACTION BUTTON
                        if (isRunning) {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        localStopping = true
                                        delay(1200)
                                        onStop(phone.id)
                                        localStopping = false
                                    }
                                },
                                enabled = !localStopping && !localStarting && !localRestarting && !isRestartingStatus,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFEE2E2), // Red 100
                                    contentColor = Color(0xFF991B1B)  // Red 800
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("stop_phone_${phone.id}"),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                if (localStopping) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = Color(0xFF991B1B),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(l("Stopping...", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(l("Stop", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        localStarting = true
                                        delay(1200)
                                        onStart(phone.id)
                                        localStarting = false
                                    }
                                },
                                enabled = isStopped && !localStarting && !localStopping,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFDCFCE7), // Green 100
                                    contentColor = Color(0xFF166534)  // Green 800
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("start_phone_${phone.id}"),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                if (localStarting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = Color(0xFF166534),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(l("Starting...", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(l("Start", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // RESTART ACTION BUTTON
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    localRestarting = true
                                    onRestart(phone.id)
                                    delay(2200)
                                    localRestarting = false
                                }
                            },
                            enabled = isRunning && !localRestarting && !isRestartingStatus && !localStarting && !localStopping,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFEF3C7), // Amber 100
                                contentColor = Color(0xFF92400E)  // Amber 800
                             ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("reboot_phone_${phone.id}"),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            if (localRestarting || isRestartingStatus) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF92400E),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Restarting...", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Restart", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Button row 2: Clone & Connect
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isCloningStatus = phone.status == "CLONING"
                        
                        // CLONE ACTION BUTTON
                        Button(
                            onClick = {
                                onClone(phone)
                            },
                            enabled = phone.status != "PROVISIONING" && phone.status != "CLONING" && !localStarting && !localStopping && !localRestarting && !isRestartingStatus,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDBEAFE), // Blue 100
                                contentColor = Color(0xFF1E40AF)  // Blue 800
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("clone_phone_${phone.id}"),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            if (isCloningStatus) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF1E40AF),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Cloning...", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.FileCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Clone", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // CONNECT TO CONTAINER / BACKUP ACTION BUTTON
                        if (phone.status == "RUNNING") {
                            Button(
                                onClick = { onSelectForRemote(phone.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BluePrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("connect_phone_${phone.id}"),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Icon(Icons.Default.CastConnected, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Connect", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = { onBackup(phone.id) },
                                enabled = false, // Must be running
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFF1F5F9), // Slate 100
                                    contentColor = Color(0xFF94A3B8)  // Slate 400
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Icon(Icons.Default.PowerOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(l("Offline", isArabic), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusChip(status: String, isArabic: Boolean) {
    val colorPair = when (status) {
        "RUNNING" -> EmeraldSuccess to EmeraldSuccess.copy(alpha = 0.15f)
        "STOPPED" -> Color.Gray to Color.Gray.copy(alpha = 0.15f)
        "RESTARTING" -> AmberWarning to AmberWarning.copy(alpha = 0.15f)
        "BACKING_UP", "CLONING", "PROVISIONING" -> CyanPrimary to CyanPrimary.copy(alpha = 0.15f)
        else -> CyanPrimary to CyanPrimary.copy(alpha = 0.15f)
    }

    Surface(
        shape = RoundedCornerShape(100),
        color = colorPair.second,
        border = BorderStroke(1.dp, colorPair.first.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(colorPair.first)
            )
            Text(
                text = if (isArabic) {
                    when (status) {
                        "RUNNING" -> "نشط"
                        "STOPPED" -> "متوقف"
                        "RESTARTING" -> "جاري التشغيل"
                        "BACKING_UP" -> "نسخ احتياطي"
                        "CLONING" -> "جاري الاستنساخ"
                        "PROVISIONING" -> "جاري التهيئة"
                        else -> status
                    }
                } else status,
                color = colorPair.first,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}

@Composable
fun SpecChip(icon: ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
        Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
    }
}

// ==========================================
// 2. REMOTE CONTROL TAB (STREAMING DEVICE VIEW)
// ==========================================
@Composable
fun RemoteControlTab(
    viewModel: CloudPhoneViewModel,
    selectedPhone: CloudPhoneEntity?,
    allPhones: List<CloudPhoneEntity>,
    isArabic: Boolean
) {
    var expandedDropdown by remember { mutableStateOf(false) }
    val activeScreen by viewModel.activeScreenState.collectAsState()
    val terminalHistory by viewModel.phoneTerminalHistory.collectAsState()
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dropdown to select different devices
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Button(
                    onClick = { expandedDropdown = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = selectedPhone?.name ?: l("No Active Stream", isArabic),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false }
                ) {
                    allPhones.forEach { phone ->
                        DropdownMenuItem(
                            text = { Text(phone.name + " (${phone.status})") },
                            onClick = {
                                viewModel.selectPhone(phone.id)
                                expandedDropdown = false
                            },
                            enabled = phone.status == "RUNNING"
                        )
                    }
                }
            }

            // Connection metrics badge
            if (selectedPhone != null && selectedPhone.status == "RUNNING") {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EmeraldSuccess.copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Wifi, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                        Text(
                            text = if (isArabic) "بث RTC نشط (40 إطار/ث، 12 ملّي ثانية)" else "RTC Stream Active (40fps, 12ms)",
                            style = MaterialTheme.typography.labelSmall.copy(color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        if (selectedPhone == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = l("Please select a cloud phone from the Devices tab to initialize the secure remote stream viewport.", isArabic),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(32.dp)
                )
            }
            return
        }

        if (selectedPhone.status != "RUNNING") {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.StopScreenShare, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                    Text(
                        text = if (isArabic) "الجهاز غير متصل أو حالته هي: ${selectedPhone.status}" else "Instance offline or provision state is: ${selectedPhone.status}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { viewModel.startPhone(selectedPhone.id) }) {
                        Text(l("Power On Node", isArabic))
                    }
                }
            }
            return
        }

        // Main remote UI with dual column for tablets / expanded or rows for compact
        BoxWithConstraints(modifier = Modifier.weight(1f)) {
            val isWide = maxWidth > 600.dp
            
            if (isWide) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // Left Column: The device interactive viewport
                    Box(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        CloudPhoneStreamingViewport(
                            selectedPhone = selectedPhone,
                            activeScreen = activeScreen,
                            terminalHistory = terminalHistory,
                            isArabic = isArabic,
                            viewModel = viewModel,
                            onExecuteCommand = { cmd -> viewModel.executePhoneTerminalCommand(cmd) },
                            onAppShortcutClick = { screen -> viewModel.setPhoneScreenState(screen) }
                        )
                    }

                    // Right Column: Remote panel shortcuts & virtual remote buttons
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        RemoteDeviceShortcutsCard(
                            activeScreen = activeScreen,
                            isArabic = isArabic,
                            onShortcutSelect = { screen -> viewModel.setPhoneScreenState(screen) }
                        )
                        VirtualHardwareButtonsCard(
                            isArabic = isArabic,
                            onHome = { viewModel.setPhoneScreenState("Launcher") },
                            onBack = { viewModel.setPhoneScreenState("Launcher") },
                            onPower = { viewModel.stopPhone(selectedPhone.id) }
                        )
                        RealtimeTerminalControllerCard(
                            terminalHistory = terminalHistory,
                            isArabic = isArabic,
                            onExecuteCommand = { cmd -> viewModel.executePhoneTerminalCommand(cmd) }
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Central phone interactive container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(440.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CloudPhoneStreamingViewport(
                            selectedPhone = selectedPhone,
                            activeScreen = activeScreen,
                            terminalHistory = terminalHistory,
                            isArabic = isArabic,
                            viewModel = viewModel,
                            onExecuteCommand = { cmd -> viewModel.executePhoneTerminalCommand(cmd) },
                            onAppShortcutClick = { screen -> viewModel.setPhoneScreenState(screen) }
                        )
                    }

                    RemoteDeviceShortcutsCard(
                        activeScreen = activeScreen,
                        isArabic = isArabic,
                        onShortcutSelect = { screen -> viewModel.setPhoneScreenState(screen) }
                    )

                    VirtualHardwareButtonsCard(
                        isArabic = isArabic,
                        onHome = { viewModel.setPhoneScreenState("Launcher") },
                        onBack = { viewModel.setPhoneScreenState("Launcher") },
                        onPower = { viewModel.stopPhone(selectedPhone.id) }
                    )

                    RealtimeTerminalControllerCard(
                        terminalHistory = terminalHistory,
                        isArabic = isArabic,
                        onExecuteCommand = { cmd -> viewModel.executePhoneTerminalCommand(cmd) }
                    )
                }
            }
        }
    }
}

// High-fidelity phone interactive frame
@Composable
fun CloudPhoneStreamingViewport(
    selectedPhone: CloudPhoneEntity,
    activeScreen: String,
    terminalHistory: List<String>,
    isArabic: Boolean = false,
    viewModel: CloudPhoneViewModel,
    onExecuteCommand: (String) -> Unit,
    onAppShortcutClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        modifier = Modifier
            .fillMaxHeight()
            .width(260.dp)
            .border(4.dp, Color(0xFF2E3A52), RoundedCornerShape(32.dp))
            .shadow(16.dp, RoundedCornerShape(32.dp)),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Status bar (Top of phone)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "10:45",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                )
                // Notch
                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .height(14.dp)
                        .clip(RoundedCornerShape(bottomStart = 10.dp, bottomEnd = 10.dp))
                        .background(Color.Black)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Wifi, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                    Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                }
            }

            // Interactive screen viewport
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(TerminalBlack)
            ) {
                AnimatedContent(
                    targetState = activeScreen,
                    label = "ScreenViewportTransition"
                ) { screen ->
                    when (screen) {
                        "Launcher" -> {
                            PhoneLauncherScreen(
                                selectedPhone = selectedPhone,
                                isArabic = isArabic,
                                onShortcutClick = onAppShortcutClick
                            )
                        }
                        "Browser" -> {
                            PhoneBrowserScreen()
                        }
                        "AppStore" -> {
                            PhoneAppStoreScreen(selectedPhone, viewModel, isArabic)
                        }
                        "Terminal" -> {
                            PhoneTerminalScreen(
                                history = terminalHistory,
                                onExecuteCommand = onExecuteCommand
                            )
                        }
                        "Settings" -> {
                            PhoneSettingsScreen(selectedPhone)
                        }
                        "WhatsApp", "Telegram", "Instagram", "TikTok", "Slack", "Docker" -> {
                            PhoneAccountSandboxScreen(
                                appName = screen,
                                selectedPhone = selectedPhone,
                                viewModel = viewModel,
                                isArabic = isArabic,
                                onBack = { onAppShortcutClick("Launcher") }
                            )
                        }
                        "PUBG Mobile", "Free Fire", "Roblox", "Subway Surfers" -> {
                            PhoneGameSandboxScreen(
                                appName = screen,
                                selectedPhone = selectedPhone,
                                viewModel = viewModel,
                                isArabic = isArabic,
                                onBack = { onAppShortcutClick("Launcher") }
                            )
                        }
                        else -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No signal", color = Color.White)
                            }
                        }
                    }
                }
            }

            // Lower phone bezels & home pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp),
                contentAlignment = Alignment.Center
            ) {
                // Home gesture bar
                Box(
                    modifier = Modifier
                        .width(72.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.Gray.copy(alpha = 0.5f))
                        .clickable { onAppShortcutClick("Launcher") }
                )
            }
        }
    }
}

@Composable
fun PhoneLauncherScreen(
    selectedPhone: CloudPhoneEntity,
    isArabic: Boolean = false,
    onShortcutClick: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1E3A8A), Color(0xFF0F172A))
                )
            )
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Clock & Dynamic Load Widget
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isArabic) "جهاز سحابي معزول" else "CloudPhone Instance",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = CyanPrimary)
                    )
                    Text(
                        text = selectedPhone.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${if (isArabic) "المعالج" else "vCPU"}: ${selectedPhone.cpuCores}", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                        Text("${if (isArabic) "الرام" else "vRAM"}: ${selectedPhone.ramGb}GB", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                    }
                }
            }

            // App Icon Shortcut Grid
            Text(
                text = if (isArabic) "التطبيقات المعزولة" else "SANDBOXED APPS",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.5f), fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(start = 4.dp)
            )

            val installedApps = selectedPhone.installedAppsRaw.split(";").filter { it.isNotEmpty() }
            val chunkedApps = installedApps.chunked(4)

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(chunkedApps) { rowApps ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowApps.forEach { app ->
                            val icon = when (app) {
                                "Browser" -> Icons.Default.Language
                                "AppStore" -> Icons.Default.Shop
                                "Terminal" -> Icons.Default.Terminal
                                "Settings" -> Icons.Default.Settings
                                "WhatsApp" -> Icons.Default.Message
                                "Telegram" -> Icons.Default.Send
                                "Instagram" -> Icons.Default.PhotoCamera
                                "TikTok" -> Icons.Default.Videocam
                                "Slack" -> Icons.Default.Forum
                                "Docker" -> Icons.Default.Layers
                                "PUBG Mobile" -> Icons.Default.Gamepad
                                "Free Fire" -> Icons.Default.Games
                                "Roblox" -> Icons.Default.Extension
                                "Subway Surfers" -> Icons.Default.DirectionsRun
                                else -> Icons.Default.Apps
                            }
                            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                PhoneLauncherAppIcon(
                                    icon = icon,
                                    label = app,
                                    onClick = { onShortcutClick(app) }
                                )
                            }
                        }
                        // Fill remaining spaces in the grid row
                        repeat(4 - rowApps.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneLauncherAppIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag("phone_app_shortcut_${label.lowercase()}")
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White.copy(alpha = 0.15f),
            modifier = Modifier.size(44.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun PhoneBrowserScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Address Bar
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.LightGray.copy(alpha = 0.4f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "https://licensing.android.org",
                fontSize = 10.sp,
                color = Color.DarkGray,
                modifier = Modifier.padding(6.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text(
                    text = "GMS Licensing Architecture",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color.Black)
                )
                Text(
                    text = "Google Mobile Services (GMS) licensing requires physical hardware compliance (CTS/VTS). For legal Cloud Android instances, virtualization architectures must employ specific techniques:\n" +
                            "1. Certified Hardware mapping: Project real physical device signatures via host emulation.\n" +
                            "2. Compatibility Sandboxing: Use microG/OpenGMS frameworks to bridge GMS dependencies without breaking distribution copyrights.\n" +
                            "3. Private Server certification: Enterprise deployments can apply to whitelist custom KVM host ranges directly with Google.",
                    fontSize = 10.sp,
                    color = Color.Black.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun PhoneAppStoreScreen(selectedPhone: CloudPhoneEntity, viewModel: CloudPhoneViewModel, isArabic: Boolean) {
    val scope = rememberCoroutineScope()
    // Local progress trackers for installing apps
    val installingMap = remember { mutableStateMapOf<String, Float>() }

    val installedApps = selectedPhone.installedAppsRaw.split(";").filter { it.isNotEmpty() }

    val storeApps = listOf(
        "Chrome" to (if (isArabic) "متصفح ويب سريع ورسمي" else "Official fast web browser"),
        "WhatsApp" to (if (isArabic) "واتساب للأعمال والتسويق الاحترافي" else "Professional business marketing sandbox"),
        "Telegram" to (if (isArabic) "تيليجرام آمن ضد الحظر" else "Secure anti-ban messaging container"),
        "Instagram" to (if (isArabic) "إدارة حسابات انستغرام ببروكسي" else "Account workspace with proxy assignment"),
        "TikTok" to (if (isArabic) "محاكي تيك توك لزيادة المشاهدات" else "Traffic-boosting account simulator"),
        "Slack" to (if (isArabic) "سلاك لإدارة فرق العمل والمؤسسات" else "Enterprise collaboration and logs"),
        "Docker" to (if (isArabic) "حاويات دوكر للمطورين" else "Test container apps natively"),
        "PUBG Mobile" to (if (isArabic) "ببجي موبايل - أداء عالي وسلس" else "PUBG Mobile - High FPS gaming"),
        "Free Fire" to (if (isArabic) "فري فاير - استجابة سريعة ومحاكاة دقيقة" else "Free Fire - Low latency simulator"),
        "Roblox" to (if (isArabic) "روبلوكس - منصة الألعاب الرائعة" else "Roblox - Full sandbox gameplay platform"),
        "Subway Surfers" to (if (isArabic) "سوبواي سيرفرز - تقدم لانهائي" else "Subway Surfers - Endless runner progression")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isArabic) "متجر التطبيقات الآمن" else "Play Store",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            if (selectedPhone.gmsLicensed) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = EmeraldSuccess.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isArabic) "مرخص CTS" else "CTS Verified",
                        color = EmeraldSuccess,
                        fontSize = 8.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = RoseError.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isArabic) "تخطي حماية جوجل" else "GMS Bypass",
                        color = RoseError,
                        fontSize = 8.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Divider(color = Color.White.copy(alpha = 0.1f))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(storeApps) { (appName, appDesc) ->
                val isInstalled = installedApps.contains(appName)
                val progress = installingMap[appName]

                AppStoreItem(
                    name = appName,
                    desc = appDesc,
                    isInstalled = isInstalled,
                    isArabic = isArabic,
                    progress = progress,
                    onInstallClick = {
                        if (!isInstalled && progress == null) {
                            scope.launch {
                                installingMap[appName] = 0.01f
                                var currentProgress = 0.01f
                                while (currentProgress < 1.0f) {
                                    delay(150)
                                    currentProgress += 0.1f + (kotlin.random.Random.nextFloat() * 0.1f)
                                    if (currentProgress >= 1.0f) {
                                        currentProgress = 1.0f
                                    }
                                    installingMap[appName] = currentProgress
                                }
                                viewModel.installAppForPhone(selectedPhone.id, appName)
                                installingMap.remove(appName)
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AppStoreItem(
    name: String,
    desc: String,
    isInstalled: Boolean,
    isArabic: Boolean,
    progress: Float?,
    onInstallClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
            Text(name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (progress != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .weight(1f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = CyanPrimary,
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )
                    Text("${(progress * 100).toInt()}%", color = CyanPrimary, fontSize = 8.sp)
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(100),
            color = if (isInstalled) EmeraldSuccess else if (progress != null) Color.Gray else CyanPrimary,
            modifier = Modifier.clickable(enabled = !isInstalled && progress == null, onClick = onInstallClick)
        ) {
            Text(
                text = if (isInstalled) (if (isArabic) "مثبت" else "Installed") else if (progress != null) (if (isArabic) "تثبيت..." else "Installing...") else (if (isArabic) "تثبيت" else "Install"),
                color = Color.Black,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun PhoneTerminalScreen(
    history: List<String>,
    onExecuteCommand: (String) -> Unit
) {
    val scrollState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var inputCommand by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack)
            .padding(8.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        LazyColumn(
            state = scrollState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(history) { log ->
                Text(
                    text = log,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = if (log.startsWith("$")) CyanPrimary else TerminalGreen,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Inside-phone keyboard input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$ ", color = CyanPrimary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            BasicTextField(
                value = inputCommand,
                onValueChange = { inputCommand = it },
                textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 6.dp)
                    .testTag("virtual_phone_terminal_input"),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputCommand.isNotEmpty()) {
                        onExecuteCommand(inputCommand)
                        inputCommand = ""
                        scope.launch {
                            delay(100)
                            scrollState.animateScrollToItem(history.size)
                        }
                    }
                })
            )
            IconButton(
                onClick = {
                    if (inputCommand.isNotEmpty()) {
                        onExecuteCommand(inputCommand)
                        inputCommand = ""
                        scope.launch {
                            delay(100)
                            scrollState.animateScrollToItem(history.size)
                        }
                    }
                },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Execute", tint = CyanPrimary, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
fun PhoneSettingsScreen(selectedPhone: CloudPhoneEntity) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E293B))
            .padding(12.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("System Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Divider(color = Color.White.copy(alpha = 0.1f))

        SettingsRow(label = "Model Name", value = selectedPhone.name)
        SettingsRow(label = "Base OS", value = selectedPhone.androidVersion)
        SettingsRow(label = "Hypervisor Driver", value = "KVM / Waydroid Native")
        SettingsRow(label = "Virtual CPUs", value = "${selectedPhone.cpuCores} cores")
        SettingsRow(label = "Allocated RAM", value = "${selectedPhone.ramGb} GB ECC")
        SettingsRow(label = "IP Pool Route", value = selectedPhone.ipAddress)
        SettingsRow(label = "GMS SafetyNet", value = if (selectedPhone.gmsLicensed) "CTS Verified (PASS)" else "microG (Bypassed)")
        SettingsRow(label = "Local Storage", value = "${selectedPhone.storageGb} GB ZFS")
    }
}

@Composable
fun SettingsRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
        Text(value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RemoteDeviceShortcutsCard(
    activeScreen: String,
    isArabic: Boolean = false,
    onShortcutSelect: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(l("QUICK SCREEN SHORTCUTS", isArabic), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Launcher", "Browser", "AppStore", "Terminal", "Settings").forEach { item ->
                    val isSelected = activeScreen == item
                    OutlinedButton(
                        onClick = { onShortcutSelect(item) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shortcut_btn_$item")
                            .height(34.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(l(item, isArabic), fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun VirtualHardwareButtonsCard(
    isArabic: Boolean = false,
    onHome: () -> Unit,
    onBack: () -> Unit,
    onPower: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(l("VIRTUAL PHONE BUTTONS", isArabic), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onBack,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back key", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(l("Back", isArabic), fontSize = 12.sp)
                }

                Button(
                    onClick = onHome,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.Home, contentDescription = "Home key", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(l("Home", isArabic), fontSize = 12.sp)
                }

                Button(
                    onClick = onPower,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError.copy(alpha = 0.15f), contentColor = RoseError),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.PowerSettingsNew, contentDescription = "Kill container", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(l("Kill VM", isArabic), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun RealtimeTerminalControllerCard(
    terminalHistory: List<String>,
    isArabic: Boolean = false,
    onExecuteCommand: (String) -> Unit
) {
    var desktopTerminalCommand by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(l("HOST COMMAND INJECTOR", isArabic), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = CyanPrimary))
            Text(l("Directly pipe shell commands into the virtual Android container hypervisor layer.", isArabic), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            
            OutlinedTextField(
                value = desktopTerminalCommand,
                onValueChange = { desktopTerminalCommand = it },
                placeholder = { Text(l("e.g. uname -a, top -n 1, getprop gms", isArabic), fontSize = 12.sp) },
                shape = RoundedCornerShape(8.dp),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("desktop_terminal_input"),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    if (desktopTerminalCommand.isNotEmpty()) {
                        onExecuteCommand(desktopTerminalCommand)
                        desktopTerminalCommand = ""
                        keyboardController?.hide()
                    }
                }),
                trailingIcon = {
                    IconButton(onClick = {
                        if (desktopTerminalCommand.isNotEmpty()) {
                            onExecuteCommand(desktopTerminalCommand)
                            desktopTerminalCommand = ""
                            keyboardController?.hide()
                        }
                    }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run")
                    }
                }
            )
        }
    }
}

// ==========================================
// 3. INFRASTRUCTURE & ARCHITECTURE GUIDE TAB
// ==========================================
@Composable
fun InfrastructureTab(viewModel: CloudPhoneViewModel, isArabic: Boolean) {
    val platformLogs by viewModel.platformLogs.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Architecture Overview Banners
        Text(
            text = l("PLATFORM METRICS & ARCHITECTURE", isArabic),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.sp)
        )

        // Telemetry Charts Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(l("Enterprise Node Bandwidth (Simulated Live)", isArabic), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                
                // Real-time custom Canvas draw chart
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalBlack)
                        .padding(4.dp)
                ) {
                    val transition = rememberInfiniteTransition(label = "telemetryChart")
                    val pulseFactor by transition.animateFloat(
                        initialValue = 0f,
                        targetValue = 2f * Math.PI.toFloat(),
                        animationSpec = infiniteRepeatable(
                            animation = tween(4000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "pulse"
                    )

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val path = Path()
                        val points = 30
                        val stepX = size.width / (points - 1)
                        val midY = size.height / 2f
                        
                        for (i in 0 until points) {
                            val x = i * stepX
                            // Combine sines to look organic
                            val angle = (i.toFloat() / points) * 6f * Math.PI.toFloat() + pulseFactor
                            val y = midY + sin(angle).toFloat() * 25f + sin(angle * 2.5f).toFloat() * 10f
                            
                            if (i == 0) {
                                path.moveTo(x, y)
                            } else {
                                path.lineTo(x, y)
                            }
                        }
                        
                        drawPath(
                            path = path,
                            color = CyanPrimary,
                            style = Stroke(width = 3.dp.toPx())
                        )
                        
                        // Draw grid lines
                        val gridCount = 4
                        val gridStepY = size.height / gridCount
                        for (k in 1 until gridCount) {
                            val y = k * gridStepY
                            drawLine(
                                color = Color.White.copy(alpha = 0.05f),
                                start = Offset(0f, y),
                                end = Offset(size.width, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(if (isArabic) "التنزيل: 2.45 جيجابت/ث" else "Inbound: 2.45 Gbps", style = MaterialTheme.typography.labelSmall, color = CyanPrimary)
                    Text(if (isArabic) "الرفع: 4.82 جيجابت/ث" else "Outbound: 4.82 Gbps", style = MaterialTheme.typography.labelSmall, color = BlueSecondary)
                    Text(if (isArabic) "إجمالي الاتصالات: 1,420" else "Total Connections: 1,420", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                }
            }
        }

        // Hypervisor Subsystem Logs
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(l("HYPERVISOR HOST EVENT LOGS", isArabic), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalBlack)
                        .padding(8.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(platformLogs) { log ->
                            Text(
                                text = log,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = Color(0xFF94A3B8), // slate 400
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // Architecture technical writeup (Resolves senior architect prompt)
        Text(
            text = l("CLOUD ARCHITECTURE SPECIFICATION", isArabic),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        ArchitectureDetailCard(
            title = l("1. Virtualization Technology Stack", isArabic),
            body = if (isArabic) {
                "• طبقة الافتراضية: نظام KVM (الآلة الافتراضية المعتمدة على النواة) مدمجاً مع QEMU لتشغيل حاويات Cuttlefish أو Waydroid الأصلية عبر LXC. يوفر سرعة تنفيذ قريبة جداً من الأداء الفعلي مع نوى مستقلة ومعزولة.\n• التخزين المدعوم: مجموعات تخزين ZFS مع تهيئة مرنة وضغط ZSTD قوي. مفعّل بميزات النسخ عند الكتابة (COW) للقطات، مما يتيح الاستنساخ الفوري لأي قسم قرص افتراضي لنظام أندرويد دون أي تكرار أولي للمساحة.\n• تسريع معالج الرسوميات: خرائط تخصيص ملفات تعريف NVIDIA GRID (vGPU) لتقسيم معالج الرسوميات (مثل NVIDIA L40S). يتيح هذا لمعالج رسوميات فيزيائي واحد معالجة تسريع واجهات OpenGL ES / Vulkan لما يصل إلى 64 شاشة أندرويد افتراضية متزامنة."
            } else {
                "• Virtualization Layer: KVM (Kernel-based Virtual Machine) combined with QEMU running cuttlefish or native Waydroid containers over LXC. Provides near-bare-metal execution speeds with individual, isolated kernels.\n• Storage Backing: ZFS storage clusters with thin-provisioning and aggressive ZSTD compression. Enabled with Copy-on-Write (COW) file snapshots which allows instant cloning of any Android virtual disk partition with zero initial storage duplication.\n• GPU Acceleration: NVIDIA GRID virtual GPU (vGPU) profile partition maps (such as NVIDIA L40S GRID). This allows a single physical GPU to handle hardware OpenGL ES / Vulkan pipeline acceleration for up to 64 virtual Android displays concurrently."
            }
        )

        ArchitectureDetailCard(
            title = l("2. GMS (Google Mobile Services) Licensing & Compliance", isArabic),
            body = if (isArabic) {
                "تطلب خدمات جوجل للهاتف المحمول (GMS) ترخيصاً للأجهزة المادية. بالنسبة للبيئات السحابية:\n• تراخيص GMS للمؤسسات: لتشغيل تطبيقات GMS الرسمية المعتمدة (مثل متجر Play، والخرائط) بشكل قانوني، يتعاون المستضيفون مع مصنعي الأجهزة المعتمدين من جوجل باستخدام ملفات تعريف السحابة AOSP بموجب تراخيص مخصصة للمجموعات الكبيرة.\n• بيئات الامتثال المعزولة (microG / OpenGMS): بالنسبة لأجهزة المحاكاة العامة، تشغل الأنظمة حزمة محاكاة microG، مما يضمن للمطورين اختبار واجهات برمجة تطبيقات الموقع، والإشعارات، وحالات تسجيل الدخول بشكل قانوني وأخلاقي دون انتهاك شروط توزيع GMS."
            } else {
                "Google Mobile Services (GMS) licensing requires physical device certification. For cloud environments:\n• Enterprise GMS Licensing: To legally run official GMS certified apps (such as Google Play, Maps), hosters partner with Google Authorized OEMs using AOSP cloud profiles under specific volume licensing.\n• Compliance Sandboxing (microG / OpenGMS): For generic sandbox VMs, standard systems run microG emulations, ensuring developers can test location APIs, notifications, and login states legally and ethically without breaching GMS distribution terms."
            }
        )

        ArchitectureDetailCard(
            title = l("3. Security & Multi-User Isolation", isArabic),
            body = if (isArabic) {
                "• بيئة السجن البرمجية (Namespace Jail): يضمن عزل مساحات الأسماء لـ LXC / Android عدم تمكن الهاتف الافتراضي (أ) من الوصول إلى عمليات أو مساحات ذاكرة الهاتف (ب).\n• تشفير البيانات: تشفير ZFS الأصلي باستخدام خوارزمية AES-256-GCM. يتم تشفير وحدة تخزين الهاتف السحابي لكل مستخدم بمفتاح رئيسي مشتق بشكل آمن من رمز جلسة تسجيل الدخول للمستخدم.\n• حارس الشبكة: توفر جسور iptables عالية السرعة شبكات فرعية مخصصة ومعزولة للبيانات. يتم حظر الأجهزة السحابية تماماً من اكتشاف الشبكة المحلية الداخلية ما لم يتم تكوين جسر افتراضي مخصص بشكل آمن."
            } else {
                "• Namespace Jail: LXC / Android namespace isolation ensures virtual phone A cannot access processes or memory spaces of phone B.\n• Data Encryption: ZFS native encryption with AES-256-GCM. Each user's cloud phone storage volume is encrypted with a master key derived securely from the user's login session token.\n• Network Guard: High-speed iptables bridging provides distinct private routing subnets. Instances are completely blocked from local intranet discovery unless a dedicated virtual bridge is securely configured."
            }
        )

        ArchitectureDetailCard(
            title = l("4. Open-Source Self-Hosted Pricing Model", isArabic),
            body = if (isArabic) {
                "• مجاني ومفتوح المصدر 100%: منصة التنسيق بالكامل، وبنيات نظام AOSP المخصصة، ولوحة بث WebRTC، وبوابة واجهة برمجة التطبيقات مجانية تماماً وبدون أي رسوم.\n• لا توجد تكاليف اشتراك: استمتع بعدد غير محدود من الأجهزة السحابية المحلية بتكلفة ترخيص تبلغ 0.00 دولار تماماً ودون رسوم اشتراك شهرية.\n• كفاءة عالية على الأجهزة الفعلية: يمكن نشره بالكامل على الأجهزة الاستهلاكية القياسية أو مزودي الحوسبة السحابية من الفئة المجانية."
            } else {
                "• 100% Free & Open-Source: The entire orchestration platform, custom AOSP system builds, WebRTC client dashboard, and API gateway are completely free of charge.\n• Zero Subscription Costs: Enjoy unlimited local Android cloud instances with absolutely $0.00 licensing or monthly subscription fees.\n• Optimized Bare-Metal Efficiency: Can be fully deployed on standard off-the-shelf consumer hardware or free tier cloud compute providers."
            }
        )

        ArchitectureDetailCard(
            title = l("5. Roadmap (MVP to Enterprise Scale)", isArabic),
            body = if (isArabic) {
                "• النسخة التجريبية (الإصدار الحالي): محاكاة واجهة برمجة تطبيقات المجموعة، وعميل تكوين أندرويد المستند بالكامل على قاعدة بيانات Room، ولوحة تحكم تفاعلية مع منفذ للأوامر عن بعد.\n• المرحلة 2: دمج بث ترميز الأجهزة المباشر WebRTC H.264 مع خطوط نقل فيديو بمعدل 60 إطاراً في الثانية.\n• المرحلة 3 للمؤسسات: توسيع نطاق Kubernetes (K8s) KubeVirt لآلاف من أجهزة أندرويد المتوازية عبر مناطق جغرافية مختلفة مع توازن ذكي للحمل الجغرافي."
            } else {
                "• MVP (Current Version): Local cluster orchestration API simulation, fully functional Room-based Android configuration client, responsive live stream and remote commands console.\n• Phase 2: WebRTC H.264 live hardware encoding stream integration with 60FPS video pipelines.\n• Phase 3 Enterprise: Kubernetes (K8s) KubeVirt scaling for thousands of parallel Android instances across global regions with smart geographical load-balancing."
            }
        )
    }
}

@Composable
fun ArchitectureDetailCard(title: String, body: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
        }
    }
}

// ==========================================
// 4. SECURITY & VPN TAB
// ==========================================
@Composable
fun SecurityVpnTab(viewModel: CloudPhoneViewModel, isArabic: Boolean) {
    var vpnEnabled by remember { mutableStateOf(true) }
    var firewallStrict by remember { mutableStateOf(false) }
    var dnsCryptEnabled by remember { mutableStateOf(true) }
    var selectedLocation by remember { mutableStateOf("US West (Oregon)") }

    // Professional Anti-Surveillance & Protection States
    var selinuxEnforced by remember { mutableStateOf(true) }
    var memoryGuardEnabled by remember { mutableStateOf(true) }
    var antiFingerprintEnabled by remember { mutableStateOf(true) }
    var camMicKillSwitch by remember { mutableStateOf(false) }
    var residentialIpSimulated by remember { mutableStateOf(true) }
    var playIntegritySpoof by remember { mutableStateOf(true) }
    var gpsSpoofingEnabled by remember { mutableStateOf(true) }

    // Live Security Logs
    val logsList = remember {
        mutableStateListOf(
            "🛡️ [SECURE] SELinux Enforced successfully on Node Group [Aether-V3]",
            "🔒 [INTEGRITY] CTS Verification reported: PASS (MEETS_STRONG_INTEGRITY)",
            "📡 [ROUTING] Active SOCKS5 Residential Bridge established on 185.220.101.44",
            "🚫 [FIREWALL] Telemetry request to 'google-analytics.com' blocked successfully",
            "⚙️ [SPOOF] Randomized IMEI for instance #01 to: 358294103859102",
            "🧩 [SANDBOX] Virtual memory space isolated; Exploit Shield active",
            "📍 [GPS] Geospatial coordinates locked and aligned with Oregon Residential IP Gateway"
        )
    }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Arabic & English Section Title
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = if (isArabic) "مركز الحماية المتقدمة | SECURITY CONTROL DESK" else "SECURITY CONTROL DESK | مركز الحماية المتقدمة",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = BluePrimary,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = l("Manage professional anti-intrusion, anti-fingerprinting, and anti-ban systems.", isArabic),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color(0xFF64748B) // Slate 500
                )
            )
        }

        // 1. Dynamic Security Status Score Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Glowy green status circle
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFFDCFCE7), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Security Active",
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = l("A+ MAXIMUM SECURITY STATE", isArabic),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                    Text(
                        text = if (isArabic) {
                            "نظام حماية احترافي ضد الاختراق، المراقبة، وحظر الحسابات نشط بالكامل."
                        } else {
                            "Professional anti-hack, anti-surveillance, and anti-ban network architecture fully active."
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1E293B) // Slate 800
                        )
                    )
                }
            }
        }

        // 2. Anti-Hacking & Kernel Isolation Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GppGood,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isArabic) "منع الاختراق وعزل النواة | Anti-Hacking" else "Anti-Hacking & Kernel Isolation (منع الاختراق وعزل النواة)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // SELinux Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "فرض حماية نظام لينكس (SELinux Strict)" else "SELinux Strict Enforcing (فرض حماية نظام لينكس)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Enforces mandatory access control and sandboxes isolated container runtimes.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = selinuxEnforced,
                        onCheckedChange = {
                            selinuxEnforced = it
                            viewModel.logPlatformEvent("Security", "SELinux Strict status altered: $it")
                            logsList.add(if (it) "🛡️ [SECURE] SELinux Policy successfully transition to ENFORCING" else "⚠️ [WARNING] SELinux switched to PERMISSIVE mode (Security compromised)")
                        }
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // Exploit Memory Shield
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "درع الذاكرة لمنع الثغرات (Memory Guard)" else "Memory Guard Exploit Shield (درع الذاكرة لمنع الثغرات)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Defends virtual device runtimes against memory injection, overflow, and hijack attacks.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = memoryGuardEnabled,
                        onCheckedChange = {
                            memoryGuardEnabled = it
                            viewModel.logPlatformEvent("Security", "Memory Guard modified: $it")
                            logsList.add(if (it) "🧩 [SANDBOX] Memory protection heap randomization enforced" else "⚠️ [WARNING] Buffer overflow protections bypassed")
                        }
                    )
                }
            }
        }

        // 3. Anti-Surveillance & Anti-Fingerprinting Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = null,
                        tint = IndigoSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isArabic) "مكافحة التجسس والتتبع | Anonymity Suite" else "Anti-Surveillance & Anonymity (مكافحة التجسس والتتبع)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // Device Fingerprint Spoofing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "تزييف وتغيير بصمة العتاد (Metadata Spoof)" else "Device Metadata Randomizer (تزييف وتغيير بصمة العتاد)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Spoofs IMEI, MAC addresses, Android IDs, and build parameters to block fingerprint-based tracking.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = antiFingerprintEnabled,
                        onCheckedChange = {
                            antiFingerprintEnabled = it
                            viewModel.logPlatformEvent("Security", "Device Fingerprint Randomizer changed: $it")
                            logsList.add(if (it) "⚙️ [SPOOF] Generated 12 fresh randomized device fingerprints" else "⚠️ [WARNING] Real MAC and hardware telemetry exposed")
                        }
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // Cam/Mic hardware isolation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "قطع الكاميرا والميكروفون برمجياً (Hardware Switch)" else "Sandbox Hardware Kill Switch (قطع الكاميرا والميكروفون)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Disconnects camera sensors and microphone modules. Feeds blank loops to apps.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = camMicKillSwitch,
                        onCheckedChange = {
                            camMicKillSwitch = it
                            viewModel.logPlatformEvent("Security", "Cam/Mic Kill Switch: $it")
                            logsList.add(if (it) "🚫 [SANDBOX] Camera & Audio streams hard-blocked at HAL level" else "🟢 [SANDBOX] Audio-visual peripherals unlocked for apps")
                        }
                    )
                }
            }
        }

        // 4. Anti-Ban, Anti-Detection & Routing Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnLock,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isArabic) "مكافحة الحظر وتغيير المواقع | Anti-Ban Suite" else "Anti-Ban & Proxy Gateway (مكافحة الحظر وتغيير المواقع)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // SOCKS5/WireGuard Residential Proxy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "بروكسي سكني مخصص (Residential Proxy)" else "Residential Proxy Tunneling (بروكسي سكني مخصص)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Routes each instance through residential IP subnets, avoiding datacenter-based account bans.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = residentialIpSimulated,
                        onCheckedChange = {
                            residentialIpSimulated = it
                            viewModel.logPlatformEvent("Security", "Residential routing switch: $it")
                            logsList.add(if (it) "📡 [ROUTING] Dynamic residential proxy gateway activated on US-EAST" else "⚠️ [WARNING] Routing downgraded to shared datacenter IP pool")
                        }
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // Play Integrity Spoofing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "محاكاة سلامة النظام والشهادات (Play Integrity)" else "Play Integrity API Attestation (محاكاة سلامة النظام والشهادات)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Bypasses SafetyNet/CTS checks to run financial and banking apps securely without detection.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = playIntegritySpoof,
                        onCheckedChange = {
                            playIntegritySpoof = it
                            viewModel.logPlatformEvent("Security", "Play integrity bypass switch: $it")
                            logsList.add(if (it) "🔒 [INTEGRITY] Strong Attestation framework injected" else "⚠️ [WARNING] Root access signature exposed to CTS tests")
                        }
                    )
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // GPS Location Alignment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isArabic) "مزامنة الموقع الجغرافي والشبكة (GPS Aligner)" else "GPS Network Aligner (مزامنة الموقع الجغرافي)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = l("Locks physical GPS coords with matching residential IP location to prevent telemetry discrepancies.", isArabic),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Switch(
                        checked = gpsSpoofingEnabled,
                        onCheckedChange = {
                            gpsSpoofingEnabled = it
                            viewModel.logPlatformEvent("Security", "GPS location alignment switch: $it")
                            logsList.add(if (it) "📍 [GPS] Coordinates synchronized automatically with US East Proxy" else "⚠️ [WARNING] Telemetry gap: Real GPS and Virtual IP locations are disjointed")
                        }
                    )
                }
            }
        }

        // 5. Live Activity Logs / Terminal (سجل الحماية الفوري)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), // Deep Slate Dark
            border = BorderStroke(1.dp, Color(0xFF334155))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF22C55E), CircleShape) // Blinking Green Dot
                        )
                        Text(
                            text = if (isArabic) "سجل الحماية الفوري | SANDBOX Threat Shield" else "SANDBOX Threat Shield (سجل الحماية الفوري)",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF8FAFC)
                            )
                        )
                    }
                    
                    // Clear log trigger
                    TextButton(
                        onClick = {
                            logsList.clear()
                            logsList.add("🛡️ [SECURE] Event logger database recycled. Standard audit active.")
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF38BDF8))
                    ) {
                        Text(l("Clear Logs", isArabic), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFF020617), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(logsList.toList().reversed()) { log ->
                            Text(
                                text = log,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = if (log.contains("WARNING")) Color(0xFFF87171) else Color(0xFF38BDF8)
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. PROVISION MODAL DIALOG
// ==========================================
@Composable
fun ProvisionDialog(
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Int, Int, Int, String, String, Boolean) -> Unit
) {
    var name by remember { mutableStateOf("Test-Agent-01") }
    var androidVersion by remember { mutableStateOf("Android 15") }
    var cpuCores by remember { mutableStateOf(4) }
    var ramGb by remember { mutableStateOf(8) }
    var storageGb by remember { mutableStateOf(128) }
    var networkProfile by remember { mutableStateOf("Secure VPN Tunnel") }
    var userProfile by remember { mutableStateOf("Clean Developer Profile") }
    var gmsLicensed by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isArabic) "تهيئة جهاز سحابي جديد" else "PROVISION NEW CLOUD PHONE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isArabic) "معرّف اسم الجهاز" else "Device Name Identifier") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_provision_name")
                )

                // Android OS
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isArabic) "صورة نظام الأندرويد" else "Android System Image", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Android 13", "Android 14", "Android 15").forEach { ver ->
                            val isSelected = androidVersion == ver
                            OutlinedButton(
                                onClick = { androidVersion = ver },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(ver, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // CPU cores selection
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isArabic) "مجدول عتاد المعالجة vCPU" else "vCPU Hardware Schedulers", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(2, 4, 8).forEach { cores ->
                            val isSelected = cpuCores == cores
                            OutlinedButton(
                                onClick = { cpuCores = cores },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "$cores نواتين" else "$cores Cores", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // RAM size selection
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isArabic) "ذاكرة النظام (ECC RAM)" else "System Memory (ECC RAM)", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4, 8, 16).forEach { gb ->
                            val isSelected = ramGb == gb
                            OutlinedButton(
                                onClick = { ramGb = gb },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("${gb}GB", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Storage
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isArabic) "قسم التخزين الصلب الافتراضي (SSD)" else "Virtual Solid State Partition (SSD)", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(64, 128, 256).forEach { gb ->
                            val isSelected = storageGb == gb
                            OutlinedButton(
                                onClick = { storageGb = gb },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("${gb}GB", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Network & Profile dropdown quick buttons
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (isArabic) "توجيه شبكة بوابة العبور" else "Gateway Network Subnet Routing", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("NAT - Standard", "Secure VPN Tunnel").forEach { net ->
                            val isSelected = networkProfile == net
                            OutlinedButton(
                                onClick = { networkProfile = net },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                    contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(if (isArabic && net == "NAT - Standard") "NAT - قياسي" else if (isArabic && net == "Secure VPN Tunnel") "نفق VPN آمن" else net, fontSize = 10.sp)
                            }
                        }
                    }
                }

                // GMS Certification Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (isArabic) "وضع ترخيص خدمات جوجل (GMS)" else "Legal GMS Certification Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(if (isArabic) "التحقق من سلامة Play عبر ملفات تعريف معتمدة." else "Verify Play Integrity via OEM AOSP certified profiles.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                    Switch(
                        checked = gmsLicensed,
                        onCheckedChange = { gmsLicensed = it },
                        modifier = Modifier.testTag("gms_license_switch")
                    )
                }

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                // Confirm / Dismiss buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(if (isArabic) "إلغاء" else "Cancel")
                    }
                    Button(
                        onClick = {
                            if (name.isNotEmpty()) {
                                onConfirm(name, androidVersion, cpuCores, ramGb, storageGb, networkProfile, userProfile, gmsLicensed)
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_provision_button")
                    ) {
                        Text(if (isArabic) "تهيئة الجهاز" else "Provision VM")
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. CLONE MODAL DIALOG
// ==========================================
@Composable
fun CloneDialog(
    sourcePhone: CloudPhoneEntity,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var destName by remember { mutableStateOf("${sourcePhone.name}-clone") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isArabic) "استنساخ جهاز سحابي" else "CLONE CLOUD PHONE INSTANCE",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                )
                Text(
                    text = if (isArabic) {
                        "سيقوم هذا بإنشاء لقطة نسخ فوري (COW) متطابقة لحجم نظام التشغيل '${sourcePhone.name}' بالكامل."
                    } else {
                        "This will create an instantaneous Copy-on-Write (COW) snapshot of '${sourcePhone.name}' system volume."
                    },
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                OutlinedTextField(
                    value = destName,
                    onValueChange = { destName = it },
                    label = { Text(if (isArabic) "اسم النسخة المستنسخة" else "Cloned Instance Name") },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_clone_name")
                )

                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(if (isArabic) "إلغاء" else "Cancel")
                    }
                    Button(
                        onClick = {
                            if (destName.isNotEmpty()) {
                                onConfirm(destName)
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_clone_button")
                    ) {
                        Text(if (isArabic) "إنشاء نسخة مستنسخة" else "Create Clone")
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneAccountSandboxScreen(
    appName: String,
    selectedPhone: CloudPhoneEntity,
    viewModel: CloudPhoneViewModel,
    isArabic: Boolean,
    onBack: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var newAccountName by remember { mutableStateOf("") }
    var newProxy by remember { mutableStateOf("") }
    var selectedDeviceProfile by remember { mutableStateOf("Google Pixel 8") }
    
    // Parse accounts
    val allAccounts = selectedPhone.accountsRaw.split(";").filter { it.isNotEmpty() }
    val appAccounts = allAccounts.filter { it.startsWith("$appName:") }.map {
        val parts = it.split(":")
        val name = parts.getOrNull(1) ?: "Default Account"
        val proxy = parts.getOrNull(2) ?: "Direct"
        name to proxy
    }

    var activeSessionAccount by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(8.dp)
    ) {
        if (activeSessionAccount != null) {
            // Simulated Active Chat / Session screen!
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable { activeSessionAccount = null }
                        )
                        Text(
                            text = "$appName: $activeSessionAccount",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = EmeraldSuccess.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "SECURE / معزول",
                            color = EmeraldSuccess,
                            fontSize = 8.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Divider(color = Color.White.copy(alpha = 0.1f))

                // Chat/Log View
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(100),
                                color = Color.White.copy(alpha = 0.1f)
                            ) {
                                Text(
                                    text = if (isArabic) "بدء بيئة الجلسة الآمنة" else "Secure session sandbox initialized",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 8.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "SYSTEM ENCRYPTED INTEGRITY LOG",
                                color = CyanPrimary,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "• Proxy tunnel active: ${appAccounts.find { it.first == activeSessionAccount }?.second ?: "Direct"}\n" +
                                        "• Device Profile spoofed: Google Pixel 8 Pro\n" +
                                        "• Anti-fingerprinting state: active\n" +
                                        "• Accounts Isolation key: AES-GCM-256-bit",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF1E293B))
                                    .padding(6.dp)
                            ) {
                                Text(
                                    text = if (isArabic) "مرحباً! هذا الحساب نشط وجاهز لاستقبال الحملات الإعلانية والمحادثات." else "Hello! This account is active and configured for professional messaging campaigns.",
                                    color = Color.White,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.1f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (isArabic) "اكتب رسالة للعملاء..." else "Type message...",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(6.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CyanPrimary,
                        modifier = Modifier.clickable { }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = Color.Black,
                            modifier = Modifier
                                .size(24.dp)
                                .padding(4.dp)
                        )
                    }
                }
            }
        } else {
            // Main App Workspace with Account Lists
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { onBack() }
                    )
                    Text(
                        text = if (isArabic) "حسابات $appName" else "$appName Sandbox",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = CyanPrimary.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { showAddDialog = true }
                ) {
                    Text(
                        text = if (isArabic) "+ إضافة حساب" else "+ Account",
                        color = CyanPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 6.dp))

            if (appAccounts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (isArabic) "لا توجد حسابات احترافية حالياً" else "No professional accounts",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) "اضغط على إضافة حساب بالخلفية الآمنة لإنشاء جلسة معزولة" else "Click add account to provision an isolated workspace session",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(appAccounts) { (name, proxy) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = name.take(1).uppercase(),
                                        color = CyanPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column {
                                    Text(
                                        text = name,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Proxy: $proxy",
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontSize = 8.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EmeraldSuccess,
                                    modifier = Modifier.clickable { activeSessionAccount = name }
                                ) {
                                    Text(
                                        text = if (isArabic) "فتح" else "Open",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = RoseError.copy(alpha = 0.2f),
                                    modifier = Modifier.clickable {
                                        viewModel.removeAccountForPhone(selectedPhone.id, appName, name)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = RoseError,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Account Dialog within phone container!
        if (showAddDialog) {
            Dialog(onDismissRequest = { showAddDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إضافة حساب $appName احترافي" else "New $appName Session",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        
                        OutlinedTextField(
                            value = newAccountName,
                            onValueChange = { newAccountName = it },
                            label = { Text(if (isArabic) "اسم الحساب / الملف" else "Profile Nickname", fontSize = 10.sp) },
                            textStyle = TextStyle(fontSize = 11.sp, color = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = newProxy,
                            onValueChange = { newProxy = it },
                            label = { Text(if (isArabic) "البروكسي (اتركه للتلقائي)" else "Residential Proxy", fontSize = 10.sp) },
                            placeholder = { Text("e.g. 185.220.101.4:8080", fontSize = 10.sp) },
                            textStyle = TextStyle(fontSize = 11.sp, color = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(
                            text = if (isArabic) "ملف بصمة العتاد النشط:" else "Device Profile Signature:",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Pixel 8", "S24 Ultra", "iPhone 15").forEach { prof ->
                                val isSelected = selectedDeviceProfile == prof
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) CyanPrimary else Color.White.copy(alpha = 0.1f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedDeviceProfile = prof }
                                ) {
                                    Text(
                                        text = prof,
                                        color = if (isSelected) Color.Black else Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            TextButton(
                                onClick = { showAddDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "إلغاء" else "Cancel", fontSize = 10.sp, color = Color.White)
                            }
                            Button(
                                onClick = {
                                    if (newAccountName.isNotEmpty()) {
                                        val proxyToUse = if (newProxy.isEmpty()) {
                                            "${kotlin.random.Random.nextInt(10, 240)}.${kotlin.random.Random.nextInt(10, 240)}.${kotlin.random.Random.nextInt(10, 240)}:8080"
                                        } else {
                                            newProxy
                                        }
                                        viewModel.addAccountForPhone(selectedPhone.id, appName, newAccountName, proxyToUse)
                                        newAccountName = ""
                                        newProxy = ""
                                        showAddDialog = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "إنشاء" else "Create", fontSize = 10.sp, color = Color.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneGameSandboxScreen(
    appName: String,
    selectedPhone: CloudPhoneEntity,
    viewModel: CloudPhoneViewModel,
    isArabic: Boolean,
    onBack: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var newGamerTag by remember { mutableStateOf("") }
    var selectedClass by remember { mutableStateOf("Assassin") }
    
    // Parse game accounts
    // Format in accountsRaw is "AppName:GamerTag:Level=X,Score=Y,Coins=Z,Class=C"
    val allAccounts = selectedPhone.accountsRaw.split(";").filter { it.isNotEmpty() }
    val appAccounts = allAccounts.filter { it.startsWith("$appName:") }.map {
        val parts = it.split(":")
        val tag = parts.getOrNull(1) ?: "Gamer"
        val progress = parts.getOrNull(2) ?: "Level=1,Score=0,Coins=100,Class=Warrior"
        tag to progress
    }

    var activeProfileName by remember { mutableStateOf<String?>(null) }
    var activeProgressStr by remember { mutableStateOf("") }

    // When a profile is opened, parse its state
    var level by remember { mutableStateOf(1) }
    var score by remember { mutableStateOf(0) }
    var coins by remember { mutableStateOf(100) }
    var characterClass by remember { mutableStateOf("Warrior") }
    var xp by remember { mutableStateOf(0) }

    LaunchedEffect(activeProfileName) {
        activeProfileName?.let { name ->
            val pStr = appAccounts.find { it.first == name }?.second ?: "Level=1,Score=0,Coins=100,Class=Warrior"
            activeProgressStr = pStr
            // Parse key-values
            val map = pStr.split(",").associate {
                val kv = it.split("=")
                (kv.getOrNull(0) ?: "") to (kv.getOrNull(1) ?: "")
            }
            level = map["Level"]?.toIntOrNull() ?: 1
            score = map["Score"]?.toIntOrNull() ?: 0
            coins = map["Coins"]?.toIntOrNull() ?: 100
            characterClass = map["Class"] ?: "Warrior"
            xp = map["XP"]?.toIntOrNull() ?: 0
        }
    }

    var isAutoFarming by remember { mutableStateOf(false) }
    
    // Auto-farming simulation coroutine
    LaunchedEffect(isAutoFarming, activeProfileName) {
        if (isAutoFarming && activeProfileName != null) {
            while (isAutoFarming) {
                delay(1000)
                xp += kotlin.random.Random.nextInt(5, 15)
                coins += kotlin.random.Random.nextInt(2, 8)
                score += kotlin.random.Random.nextInt(10, 25)
                
                // Level Up Check
                val xpNeeded = level * 100
                if (xp >= xpNeeded) {
                    xp -= xpNeeded
                    level += 1
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .padding(8.dp)
    ) {
        if (activeProfileName != null) {
            // Gameplay Simulation Screen
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Gameplay Header
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable { 
                                    isAutoFarming = false
                                    activeProfileName = null 
                                }
                        )
                        Text(
                            text = "$appName - $activeProfileName",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = CyanPrimary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "60 FPS • 12ms",
                            color = CyanPrimary,
                            fontSize = 8.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Divider(color = Color.White.copy(alpha = 0.1f))

                // Interactive Gaming Area / Telemetry Console
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Scorecard and stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isArabic) "المستوى" else "Level", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp)
                                Text("$level", color = CyanPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isArabic) "الذهب / العملات" else "Gold / Coins", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp)
                                Text("$coins", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (isArabic) "النقاط" else "Score", color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp)
                                Text("$score", color = EmeraldSuccess, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }

                    // XP Progress bar
                    val xpNeeded = level * 100
                    val xpProgress = (xp.toFloat() / xpNeeded).coerceIn(0f, 1f)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(6.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("XP Progress (${(xpProgress * 100).toInt()}%)", color = Color.White.copy(alpha = 0.7f), fontSize = 8.sp)
                            Text("$xp / $xpNeeded XP", color = Color.White, fontSize = 8.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { xpProgress },
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                            color = CyanPrimary,
                            trackColor = Color.White.copy(alpha = 0.1f)
                        )
                    }

                    // Simulated game graphic with moving stars or arena
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF020617))
                            .border(1.dp, CyanPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing some cool background game graphics dynamically
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Animated decorative lines
                            val lines = 8
                            for (i in 0 until lines) {
                                val offsetMultiplier = (i.toFloat() / lines)
                                val x = size.width * offsetMultiplier
                                drawCircle(
                                    color = CyanPrimary.copy(alpha = 0.05f),
                                    radius = size.minDimension * 0.4f * offsetMultiplier,
                                    center = center,
                                    style = Stroke(width = 1.dp.toPx())
                                )
                            }
                        }
                        
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (characterClass == "Sniper") Icons.Default.Adjust else Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = "CLASS: $characterClass",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isAutoFarming) 
                                    (if (isArabic) "البوت نشط: جاري جمع العملات تلقائياً..." else "AUTO BOT: Farming gold & XP...") 
                                    else (if (isArabic) "جاهز للعب والمنافسة" else "Ready to rumble!"),
                                color = if (isAutoFarming) EmeraldSuccess else Color.White.copy(alpha = 0.5f),
                                fontSize = 9.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Interactive Action Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play / Tap Button
                        Button(
                            onClick = {
                                xp += kotlin.random.Random.nextInt(8, 18)
                                coins += kotlin.random.Random.nextInt(4, 12)
                                score += kotlin.random.Random.nextInt(20, 45)
                                if (xp >= level * 100) {
                                    xp -= level * 100
                                    level += 1
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isArabic) "🎮 العب الآن / اضغط للتجميع" else "🎮 Tap to Play / Farm", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        // Auto Bot Switch
                        Surface(
                            shape = RoundedCornerShape(100),
                            color = if (isAutoFarming) EmeraldSuccess.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.1f),
                            border = BorderStroke(1.dp, if (isAutoFarming) EmeraldSuccess else Color.White.copy(alpha = 0.3f)),
                            modifier = Modifier.clickable { isAutoFarming = !isAutoFarming }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SmartButton,
                                    contentDescription = null,
                                    tint = if (isAutoFarming) EmeraldSuccess else Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (isArabic) "بوت تلقائي" else "Auto Bot",
                                    color = if (isAutoFarming) EmeraldSuccess else Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Persistence Row (Crucial for user request!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            // Save progress securely in Room DB!
                            activeProfileName?.let { tag ->
                                val newProgress = "Level=$level,Score=$score,Coins=$coins,Class=$characterClass,XP=$xp"
                                viewModel.removeAccountForPhone(selectedPhone.id, appName, tag)
                                viewModel.addAccountForPhone(selectedPhone.id, appName, tag, newProgress)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Text(
                                text = if (isArabic) "حفظ ومزامنة التقدم السحابي" else "Save & Sync Progress",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else {
            // Main Games Sandbox Profiles Manager
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { onBack() }
                    )
                    Text(
                        text = if (isArabic) "حسابات ومستوى $appName" else "$appName Sandbox",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = CyanPrimary.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { showAddDialog = true }
                ) {
                    Text(
                        text = if (isArabic) "+ ملف لاعب جديد" else "+ New Gamer Profile",
                        color = CyanPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 6.dp))

            if (appAccounts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gamepad,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (isArabic) "لا توجد ملفات للاعبين حالياً" else "No gamer profiles",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) 
                                "أنشئ حساب لاعب جديد ببيئة معزولة لبدء المنافسة وحفظ مستوى تقدمك محلياً وسحابياً" 
                                else "Create a new isolated game account to play and save your gameplay stats",
                            color = Color.White.copy(alpha = 0.4f),
                            fontSize = 9.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(appAccounts) { (tag, progress) ->
                        // Parse Level/Class/Coins
                        val map = progress.split(",").associate {
                            val kv = it.split("=")
                            (kv.getOrNull(0) ?: "") to (kv.getOrNull(1) ?: "")
                        }
                        val lvl = map["Level"] ?: "1"
                        val coinsNum = map["Coins"] ?: "100"
                        val heroClass = map["Class"] ?: "Warrior"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = tag.take(1).uppercase(),
                                        color = CyanPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Column {
                                    Text(
                                        text = tag,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Lvl $lvl ($heroClass) • $coinsNum Gold",
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontSize = 8.sp
                                    )
                                }
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = EmeraldSuccess,
                                    modifier = Modifier.clickable { 
                                        activeProfileName = tag 
                                    }
                                ) {
                                    Text(
                                        text = if (isArabic) "تشغيل اللعبة" else "Launch",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = RoseError.copy(alpha = 0.2f),
                                    modifier = Modifier.clickable {
                                        viewModel.removeAccountForPhone(selectedPhone.id, appName, tag)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = RoseError,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Game Account Dialog within phone container!
        if (showAddDialog) {
            Dialog(onDismissRequest = { showAddDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF151D30)),
                    modifier = Modifier.padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isArabic) "إنشاء حساب لاعب جديد" else "New Gamer Profile",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        
                        OutlinedTextField(
                            value = newGamerTag,
                            onValueChange = { newGamerTag = it },
                            label = { Text(if (isArabic) "اسم اللاعب (GamerTag)" else "Gamer Tag", fontSize = 10.sp) },
                            textStyle = TextStyle(fontSize = 11.sp, color = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(
                            text = if (isArabic) "اختر فئة البطل / الشخصية:" else "Select Character Class:",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Sniper", "Warrior", "Assassin").forEach { heroClass ->
                                val isSelected = selectedClass == heroClass
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) CyanPrimary else Color.White.copy(alpha = 0.1f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedClass = heroClass }
                                ) {
                                    Text(
                                        text = heroClass,
                                        color = if (isSelected) Color.Black else Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            TextButton(
                                onClick = { showAddDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "إلغاء" else "Cancel", fontSize = 10.sp, color = Color.White)
                            }
                            Button(
                                onClick = {
                                    if (newGamerTag.isNotEmpty()) {
                                        val initialProgress = "Level=1,Score=0,Coins=150,Class=$selectedClass,XP=0"
                                        viewModel.addAccountForPhone(selectedPhone.id, appName, newGamerTag, initialProgress)
                                        newGamerTag = ""
                                        showAddDialog = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isArabic) "إنشاء" else "Create", fontSize = 10.sp, color = Color.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

