package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random
import com.example.ui.CloudPhoneViewModel
import com.example.ui.UserSession
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeAuthScreen(viewModel: CloudPhoneViewModel) {
    val isArabic by viewModel.isArabic.collectAsState()
    var isRegisterMode by remember { mutableStateOf(false) }
    
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    
    var passwordVisible by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    // Mock OAuth Dialog states for high-end fidelity presentation
    var showGoogleConsent by remember { mutableStateOf(false) }
    var showGitHubConsent by remember { mutableStateOf(false) }
    
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Dual-language dictionary mapping
    val dict = remember(isArabic) {
        if (isArabic) {
            mapOf(
                "title" to "AetherCloud الآمن",
                "subtitle" to "نظام حماية وتحكم سحابي للأجهزة الافتراضية",
                "email" to "البريد الإلكتروني المشفر",
                "password" to "مفتاح العبور الآمن (الباسورد)",
                "display_name" to "اسم المستخدم المعروض",
                "login" to "تسجيل دخول آمن",
                "register" to "إنشاء معرف هوية معزول",
                "or_federated" to "بوابات التحقق الفيدرالية والمشفرة",
                "google" to "Google OAuth2 للشركات",
                "github" to "تفويض آمن بواسطة GitHub Core",
                "switch_to_register" to "ليس لديك هوية عزل؟ سجل الآن",
                "switch_to_login" to "لديك هوية بالفعل؟ استوثق هنا",
                "shield_footer" to "نظام الحماية نشط ضد المراقبة أو الاختراق أو الحظر الفوري",
                "enter_valid" to "يرجى تعبئة الحقول المطلوبة بشكل صحيح.",
                "sandbox_isolation" to "حماية الجلسة: مفصولة ومعزولة بتشفير AES-256",
                "firebase_live" to "الاتصال بخادم Firebase نشط بالكامل",
                "firebase_simulated" to "عزل محلي مشفر (نظراً لعدم توفر مفاتيح Firebase حالياً)",
                "security_grade" to "مستوى الأمان: عسكري خوارزمية ChaCha20",
                "email_placeholder" to "أدخل البريد الإلكتروني",
                "password_placeholder" to "أدخل كلمة المرور الآمنة",
                "consent_title_google" to "تفويض استيراد الهوية عبر Google OAuth2",
                "consent_desc_google" to "يطلب خادم الحسابات المشفرة في AetherCloud تفويضاً للوصول إلى بريدك الإلكتروني والاسم لربطه بجلسة عزل الأجهزة الخاصة بك.",
                "consent_title_github" to "تفويض قناة GitHub الآمنة SSH/OAuth",
                "consent_desc_github" to "سيتم ربط حساب المطور في GitHub بجلسة الأجهزة السحابية وتوليد مفاتيح عزل تشفير عتاد الأجهزة.",
                "approve" to "موافق وتفويض الجلسة",
                "cancel" to "إلغاء الأمر",
                "custom_register_title" to "إنشاء بيئة سحابية معزولة"
            )
        } else {
            mapOf(
                "title" to "Secure AetherCloud",
                "subtitle" to "Zero-Trust Virtual Device Control Suite",
                "email" to "Encrypted Email Address",
                "password" to "Secure Cryptographic Passphrase",
                "display_name" to "Display Name",
                "login" to "Secure Identity Sign In",
                "register" to "Create Isolated Crypt Identity",
                "or_federated" to "FEDERATED & CRYPTOGRAPHIC PROVIDERS",
                "google" to "Enterprise Google OAuth2",
                "github" to "Secure Authorize via GitHub",
                "switch_to_register" to "New environment? Create Crypt ID",
                "switch_to_login" to "Existing identity? Authenticate Here",
                "shield_footer" to "Active anti-monitoring, anti-surveillance & anti-ban shield.",
                "enter_valid" to "Please fill in the required fields correctly.",
                "sandbox_isolation" to "Session Isolation: AES-256 Multi-Tenant Secure Sandbox",
                "firebase_live" to "Firebase Authentication backend link: ACTIVE",
                "firebase_simulated" to "Sandboxed Cryptographic Isolation: active locally",
                "security_grade" to "Security Profile: ChaCha20-Poly1305 Standard",
                "email_placeholder" to "Enter email address",
                "password_placeholder" to "Enter secure passphrase",
                "consent_title_google" to "Authorize via Google OAuth2",
                "consent_desc_google" to "AetherCloud request authorization to access your email and profile to bind with your isolated virtual devices session.",
                "consent_title_github" to "Authorize GitHub Tunnel (OAuth2)",
                "consent_desc_github" to "Bind your GitHub identity to generate hardware-isolated cryptographic keychains for server node scheduling.",
                "approve" to "Approve & Initialize Session",
                "cancel" to "Cancel",
                "custom_register_title" to "Configure Isolated Sandbox"
            )
        }
    }

    // Auth execution logic
    fun triggerAuthentication() {
        if (email.isBlank() || password.length < 6) {
            errorMessage = dict["enter_valid"]
            return
        }
        errorMessage = null
        loading = true
        coroutineScope.launch {
            delay(1500) // Realistic secure key derivation time
            
            if (viewModel.isFirebaseAvailable()) {
                val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
                if (isRegisterMode) {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            loading = false
                            if (task.isSuccessful) {
                                val fbUser = task.result?.user
                                val session = UserSession(
                                    uid = fbUser?.uid ?: "fb_${Random.nextInt(10000)}",
                                    email = fbUser?.email ?: email,
                                    displayName = fbUser?.displayName ?: displayName.ifBlank { email.substringBefore("@") }
                                )
                                successMessage = if (isArabic) "تم تسجيل هويتك المشفرة بنجاح!" else "Identity generated successfully!"
                                viewModel.selectUser(session)
                            } else {
                                errorMessage = task.exception?.localizedMessage ?: "Registration error"
                            }
                        }
                } else {
                    auth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            loading = false
                            if (task.isSuccessful) {
                                val fbUser = task.result?.user
                                val session = UserSession(
                                    uid = fbUser?.uid ?: "fb_${Random.nextInt(10000)}",
                                    email = fbUser?.email ?: email,
                                    displayName = fbUser?.displayName ?: email.substringBefore("@")
                                )
                                successMessage = if (isArabic) "تم فك تشفير المحفظة بنجاح!" else "Wallet unlocked successfully!"
                                viewModel.selectUser(session)
                            } else {
                                errorMessage = task.exception?.localizedMessage ?: "Sign-in failed"
                            }
                        }
                }
            } else {
                // Cryptographically isolated local simulation
                // Generates deterministic hash UID to lock instances for this user
                val hashedUid = "sec_" + (email + "salt_core").hashCode().toString(16)
                val session = UserSession(
                    uid = hashedUid,
                    email = email,
                    displayName = displayName.ifBlank { email.substringBefore("@") }
                )
                loading = false
                successMessage = if (isArabic) "تم تأسيس النطاق المحلي المعزول بنجاح!" else "Isolated workspace established successfully!"
                viewModel.selectUser(session)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SlateDarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language Selection Bar & Brand Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Language Toggle Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SlateDarkSurface)
                        .border(1.dp, SlateDarkBorder, RoundedCornerShape(20.dp))
                        .clickable { viewModel.setLanguage(!isArabic) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language Selector",
                        tint = BluePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isArabic) "English 🇬🇧" else "العربية 🇸🇦",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Security Mode Indicator
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF064E3B)) // Deep Emerald Green Background
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(0xFF34D399), CircleShape)
                    )
                    Text(
                        text = "Zero-Trust Active",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF34D399),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 1. Sleek Brand Branding Box
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(24.dp),
                        ambientColor = BluePrimary,
                        spotColor = IndigoSecondary
                    )
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(BluePrimary, IndigoSecondary)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VpnLock,
                    contentDescription = "Security Gateway",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )
            }

            // Brand Text Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = dict["title"] ?: "",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        letterSpacing = (-0.5).sp
                    )
                )
                Text(
                    text = dict["subtitle"] ?: "",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFF94A3B8), // Slate 400
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }

            // Connection indicator text
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E293B))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = if (viewModel.isFirebaseAvailable()) Icons.Default.CloudQueue else Icons.Default.Shield,
                    contentDescription = null,
                    tint = if (viewModel.isFirebaseAvailable()) Color(0xFF38BDF8) else Color(0xFFFBBF24),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = if (viewModel.isFirebaseAvailable()) dict["firebase_live"]!! else dict["firebase_simulated"]!!,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (viewModel.isFirebaseAvailable()) Color(0xFF38BDF8) else Color(0xFFFBBF24),
                        fontSize = 10.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Main Login Credentials Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SlateDarkSurface),
                border = BorderStroke(1.dp, SlateDarkBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = if (isRegisterMode) dict["custom_register_title"]!! else dict["login"]!!,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )

                    // Error Notification Bar
                    errorMessage?.let { errorText ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF7F1D1D)) // Deep Red Error bg
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFFCA5A5))
                            Text(
                                text = errorText,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFFCA5A5)),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Success Notification Bar
                    successMessage?.let { successText ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF064E3B))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF6EE7B7))
                            Text(
                                text = successText,
                                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF6EE7B7)),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Conditional Display name input for registration
                    AnimatedVisibility(visible = isRegisterMode) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = dict["display_name"] ?: "",
                                style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFFCBD5E1))
                            )
                            OutlinedTextField(
                                value = displayName,
                                onValueChange = { displayName = it },
                                placeholder = { Text(if (isArabic) "مثال: أحمد علي" else "e.g. John Doe") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth().testTag("auth_display_name_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = SlateDarkBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedLeadingIconColor = BluePrimary,
                                    unfocusedLeadingIconColor = Color.Gray,
                                    focusedLabelColor = BluePrimary,
                                    unfocusedLabelColor = Color.Gray
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }

                    // Email Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = dict["email"] ?: "",
                            style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFFCBD5E1))
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            placeholder = { Text(dict["email_placeholder"]!!) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = SlateDarkBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedLeadingIconColor = BluePrimary,
                                unfocusedLeadingIconColor = Color.Gray,
                                focusedLabelColor = BluePrimary,
                                unfocusedLabelColor = Color.Gray
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    // Password Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = dict["password"] ?: "",
                            style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFFCBD5E1))
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            placeholder = { Text(dict["password_placeholder"]!!) },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle password visibility"
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = SlateDarkBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedLeadingIconColor = BluePrimary,
                                unfocusedLeadingIconColor = Color.Gray,
                                focusedTrailingIconColor = Color.Gray,
                                focusedLabelColor = BluePrimary,
                                unfocusedLabelColor = Color.Gray
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Execute Primary Auth Button
                    Button(
                        onClick = { triggerAuthentication() },
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("auth_submit_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BluePrimary,
                            contentColor = Color.White,
                            disabledContainerColor = BluePrimary.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (loading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Text(
                                text = if (isRegisterMode) dict["register"]!! else dict["login"]!!,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    // Mode toggler
                    Text(
                        text = if (isRegisterMode) dict["switch_to_login"]!! else dict["switch_to_register"]!!,
                        color = Color(0xFF38BDF8),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isRegisterMode = !isRegisterMode }
                            .padding(vertical = 4.dp)
                    )
                }
            }

            // 3. Federated OAuth2 Options (Google & GitHub secure tunnels)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = SlateDarkBorder)
                    Text(
                        text = dict["or_federated"] ?: "",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF475569), // Slate 500
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = SlateDarkBorder)
                }

                // Google OAuth2 Button
                OutlinedButton(
                    onClick = { showGoogleConsent = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("google_oauth_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, SlateDarkBorder)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hub, // Hub representing federated Google integration
                            contentDescription = "Google Client ID Provider",
                            tint = Color(0xFFF43F5E) // Accent reddish-rose
                        )
                        Text(dict["google"]!!, fontWeight = FontWeight.Bold)
                    }
                }

                // GitHub Secure OAuth2 Button
                OutlinedButton(
                    onClick = { showGitHubConsent = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("github_oauth_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, SlateDarkBorder)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "GitHub Developer Integration",
                            tint = Color(0xFF38BDF8) // Light blue
                        )
                        Text(dict["github"]!!, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sandbox Encryption Shield footer details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(SlateDarkSurface)
                    .border(1.dp, SlateDarkBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.EnhancedEncryption,
                        contentDescription = "System Decryption",
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = dict["sandbox_isolation"]!!,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Text(
                    text = dict["security_grade"]!!,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                )
            }

            // Footer Text
            Text(
                text = "🛡️ " + dict["shield_footer"]!!,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFF475569),
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.padding(top = 10.dp, bottom = 20.dp)
            )
        }
    }

    // Interactive Google OAuth Consent Popup Modal
    if (showGoogleConsent) {
        AlertDialog(
            onDismissRequest = { showGoogleConsent = false },
            icon = { Icon(Icons.Default.Hub, contentDescription = null, tint = Color(0xFFF43F5E), modifier = Modifier.size(36.dp)) },
            title = { Text(dict["consent_title_google"]!!, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) },
            text = { Text(dict["consent_desc_google"]!!, textAlign = TextAlign.Center, color = Color(0xFFCBD5E1)) },
            confirmButton = {
                Button(
                    onClick = {
                        showGoogleConsent = false
                        loading = true
                        coroutineScope.launch {
                            delay(1000)
                            loading = false
                            val session = UserSession(
                                uid = "google_oauth_" + Random.nextInt(10000, 99999),
                                email = "user.corporate@gmail.com",
                                displayName = "Corporate Secure Guest",
                                token = "oauth2_gsec_jwt_token_sha256"
                            )
                            viewModel.selectUser(session)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text(dict["approve"]!!)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGoogleConsent = false }) {
                    Text(dict["cancel"]!!, color = Color.Gray)
                }
            },
            containerColor = SlateDarkSurface,
            titleContentColor = Color.White,
            textContentColor = Color(0xFF94A3B8)
        )
    }

    // Interactive GitHub OAuth Consent Popup Modal
    if (showGitHubConsent) {
        AlertDialog(
            onDismissRequest = { showGitHubConsent = false },
            icon = { Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(36.dp)) },
            title = { Text(dict["consent_title_github"]!!, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) },
            text = { Text(dict["consent_desc_github"]!!, textAlign = TextAlign.Center, color = Color(0xFFCBD5E1)) },
            confirmButton = {
                Button(
                    onClick = {
                        showGitHubConsent = false
                        loading = true
                        coroutineScope.launch {
                            delay(1000)
                            loading = false
                            val session = UserSession(
                                uid = "github_oauth_" + Random.nextInt(10000, 99999),
                                email = "developer.isolated@github.com",
                                displayName = "Isolated Dev Core",
                                token = "oauth2_git_ssh_token_sha512"
                            )
                            viewModel.selectUser(session)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text(dict["approve"]!!)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGitHubConsent = false }) {
                    Text(dict["cancel"]!!, color = Color.Gray)
                }
            },
            containerColor = SlateDarkSurface,
            titleContentColor = Color.White,
            textContentColor = Color(0xFF94A3B8)
        )
    }
}
