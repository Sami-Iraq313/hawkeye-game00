package com.example.data

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlin.random.Random

class CloudPhoneRepository(private val dao: CloudPhoneDao) {

    val allPhones: Flow<List<CloudPhoneEntity>> = dao.getAllPhones()

    fun getPhonesByUser(userId: String): Flow<List<CloudPhoneEntity>> {
        return dao.getPhonesByUser(userId)
    }

    suspend fun getPhoneById(id: Int): CloudPhoneEntity? {
        return dao.getPhoneById(id)
    }

    suspend fun insertPhone(phone: CloudPhoneEntity): Long {
        return dao.insertPhone(phone)
    }

    suspend fun updatePhone(phone: CloudPhoneEntity) {
        dao.updatePhone(phone)
    }

    suspend fun deletePhoneById(id: Int) {
        dao.deletePhoneById(id)
    }

    // High-fidelity background simulation tasks
    suspend fun provisionPhone(
        userId: String,
        name: String,
        androidVersion: String,
        cpuCores: Int,
        ramGb: Int,
        storageGb: Int,
        networkProfile: String,
        userProfile: String,
        gmsLicensed: Boolean
    ) {
        val ipRandom = "${Random.nextInt(10, 192)}.${Random.nextInt(0, 168)}.${Random.nextInt(1, 254)}.${Random.nextInt(2, 254)}"
        val newPhone = CloudPhoneEntity(
            userId = userId,
            name = name,
            status = "PROVISIONING",
            androidVersion = androidVersion,
            cpuCores = cpuCores,
            ramGb = ramGb,
            storageGb = storageGb,
            networkProfile = networkProfile,
            userProfile = userProfile,
            gmsLicensed = gmsLicensed,
            ipAddress = ipRandom,
            systemLoadCpu = 0f,
            systemLoadRam = 0f
        )
        val id = dao.insertPhone(newPhone).toInt()
        
        // Simulate remote hypervisor initialization
        delay(2500)
        
        val loadedPhone = dao.getPhoneById(id)
        if (loadedPhone != null) {
            dao.updatePhone(
                loadedPhone.copy(
                    status = "RUNNING",
                    systemLoadCpu = Random.nextFloat() * 15f + 5f,
                    systemLoadRam = Random.nextFloat() * 25f + 10f
                )
            )
        }
    }

    suspend fun clonePhone(sourceId: Int, destinationName: String) {
        val source = dao.getPhoneById(sourceId) ?: return
        val ipRandom = "${Random.nextInt(10, 192)}.${Random.nextInt(0, 168)}.${Random.nextInt(1, 254)}.${Random.nextInt(2, 254)}"
        
        // Create cloned placeholder in backing up state first
        val clonePlaceholder = source.copy(
            id = 0,
            name = destinationName,
            status = "CLONING",
            ipAddress = ipRandom,
            createdAt = System.currentTimeMillis(),
            lastBackupTime = 0L,
            systemLoadCpu = 0f,
            systemLoadRam = 0f
        )
        val clonedId = dao.insertPhone(clonePlaceholder).toInt()
        
        // Wait to simulate snapshot duplication and storage allocating
        delay(3000)
        
        val finalizedClone = dao.getPhoneById(clonedId)
        if (finalizedClone != null) {
            dao.updatePhone(
                finalizedClone.copy(
                    status = "RUNNING",
                    systemLoadCpu = Random.nextFloat() * 20f + 10f,
                    systemLoadRam = Random.nextFloat() * 30f + 15f
                )
            )
        }
    }

    suspend fun restartPhone(id: Int) {
        val phone = dao.getPhoneById(id) ?: return
        dao.updatePhone(phone.copy(status = "RESTARTING", systemLoadCpu = 0f, systemLoadRam = 0f))
        
        // Wait to simulate ACPI reboot
        delay(2000)
        
        val rebooted = dao.getPhoneById(id)
        if (rebooted != null) {
            dao.updatePhone(
                rebooted.copy(
                    status = "RUNNING",
                    systemLoadCpu = Random.nextFloat() * 10f + 5f,
                    systemLoadRam = Random.nextFloat() * 20f + 10f
                )
            )
        }
    }

    suspend fun backupPhone(id: Int) {
        val phone = dao.getPhoneById(id) ?: return
        dao.updatePhone(phone.copy(status = "BACKING_UP"))
        
        // Wait to simulate incremental ZFS send/receive block copy
        delay(2500)
        
        val backedUp = dao.getPhoneById(id)
        if (backedUp != null) {
            dao.updatePhone(
                backedUp.copy(
                    status = "RUNNING",
                    lastBackupTime = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun stopPhone(id: Int) {
        val phone = dao.getPhoneById(id) ?: return
        dao.updatePhone(phone.copy(status = "STOPPED", systemLoadCpu = 0f, systemLoadRam = 0f))
    }

    suspend fun startPhone(id: Int) {
        val phone = dao.getPhoneById(id) ?: return
        dao.updatePhone(phone.copy(status = "RUNNING", systemLoadCpu = 5f, systemLoadRam = 15f))
    }

    suspend fun populateDefaultDataIfEmpty(userId: String) {
        val count = dao.getPhonesByUser(userId).first().size
        if (count == 0) {
            val defaults = listOf(
                CloudPhoneEntity(
                    userId = userId,
                    name = "US-West-Dev-01",
                    status = "RUNNING",
                    androidVersion = "Android 15",
                    cpuCores = 4,
                    ramGb = 8,
                    storageGb = 128,
                    networkProfile = "Secure VPN Tunnel",
                    userProfile = "Clean Developer Profile",
                    gmsLicensed = true,
                    ipAddress = "10.128.0.4",
                    systemLoadCpu = 14.5f,
                    systemLoadRam = 45.2f,
                    lastBackupTime = System.currentTimeMillis() - 86400000,
                    appDataSizeMb = 1450,
                    activeApp = "System Launcher",
                    installedAppsRaw = "Browser;AppStore;Terminal;Settings;Slack",
                    accountsRaw = ""
                ),
                CloudPhoneEntity(
                    userId = userId,
                    name = "Sandbox-QA-02",
                    status = "RUNNING",
                    androidVersion = "Android 14",
                    cpuCores = 2,
                    ramGb = 4,
                    storageGb = 64,
                    networkProfile = "NAT - Standard",
                    userProfile = "Default Sandbox",
                    gmsLicensed = false,
                    ipAddress = "10.144.1.18",
                    systemLoadCpu = 42.1f,
                    systemLoadRam = 78.5f,
                    lastBackupTime = 0L,
                    appDataSizeMb = 420,
                    activeApp = "Chrome",
                    installedAppsRaw = "Browser;AppStore;Terminal;Settings;WhatsApp;Telegram",
                    accountsRaw = "WhatsApp:Support 1:192.168.1.100;Telegram:Dev Chat:127.0.0.1"
                ),
                CloudPhoneEntity(
                    userId = userId,
                    name = "Mktg-Automation-03",
                    status = "STOPPED",
                    androidVersion = "Android 13",
                    cpuCores = 8,
                    ramGb = 16,
                    storageGb = 256,
                    networkProfile = "Secure VPN Tunnel",
                    userProfile = "Enterprise MDM",
                    gmsLicensed = true,
                    ipAddress = "10.192.12.50",
                    systemLoadCpu = 0f,
                    systemLoadRam = 0f,
                    lastBackupTime = System.currentTimeMillis() - 4800000,
                    appDataSizeMb = 5600,
                    activeApp = "Instagram",
                    installedAppsRaw = "Browser;AppStore;Terminal;Settings;WhatsApp;Instagram;TikTok",
                    accountsRaw = "WhatsApp:Marketing Corp:185.220.101.4;Instagram:Aether Ads:82.102.23.12;TikTok:Viral Sandbox:45.12.8.99"
                )
            )
            for (phone in defaults) {
                dao.insertPhone(phone)
            }
        }
    }
}
