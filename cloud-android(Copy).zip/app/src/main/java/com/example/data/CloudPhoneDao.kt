package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CloudPhoneDao {
    @Query("SELECT * FROM cloud_phones ORDER BY lastOpenedTime DESC, id ASC")
    fun getAllPhones(): Flow<List<CloudPhoneEntity>>

    @Query("SELECT * FROM cloud_phones WHERE userId = :userId ORDER BY lastOpenedTime DESC, id ASC")
    fun getPhonesByUser(userId: String): Flow<List<CloudPhoneEntity>>

    @Query("SELECT * FROM cloud_phones WHERE id = :id")
    suspend fun getPhoneById(id: Int): CloudPhoneEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhone(phone: CloudPhoneEntity): Long

    @Update
    suspend fun updatePhone(phone: CloudPhoneEntity)

    @Query("DELETE FROM cloud_phones WHERE id = :id")
    suspend fun deletePhoneById(id: Int)

    @Query("DELETE FROM cloud_phones")
    suspend fun deleteAll()
}
