package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cloud_phones")
data class CloudPhoneEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String = "default_user",
    val name: String,
    val status: String, // "RUNNING", "STOPPED", "BACKING_UP", "CLONING", "PROVISIONING", "RESTARTING"
    val androidVersion: String, // "Android 13", "Android 14", "Android 15"
    val cpuCores: Int, // 2, 4, 8, 16
    val ramGb: Int, // 4, 8, 12, 16
    val storageGb: Int, // 32, 64, 128, 256
    val networkProfile: String, // "NAT - Standard", "Bridged - Public IP", "Secure VPN Tunnel", "Tor Routing"
    val userProfile: String, // "Default Sandbox", "Enterprise MDM", "Clean Developer Profile"
    val gmsLicensed: Boolean,
    val createdAt: Long = System.currentTimeMillis(),
    val ipAddress: String,
    val activeApp: String = "System Launcher",
    val systemLoadCpu: Float = 0.0f,
    val systemLoadRam: Float = 0.0f,
    val lastBackupTime: Long = 0L,
    val appDataSizeMb: Int = 120,
    val installedAppsRaw: String = "Browser;AppStore;Terminal;Settings",
    val accountsRaw: String = "",
    val lastOpenedTime: Long = 0L
)
