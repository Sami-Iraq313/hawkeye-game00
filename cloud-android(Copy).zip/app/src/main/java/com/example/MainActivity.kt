package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.CloudPhoneViewModel
import com.example.ui.screens.MainDashboardContainer
import com.example.ui.screens.WelcomeAuthScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: CloudPhoneViewModel = viewModel()
                    val currentUser by viewModel.currentUser.collectAsState()
                    
                    if (currentUser == null) {
                        WelcomeAuthScreen(viewModel = viewModel)
                    } else {
                        MainDashboardContainer(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
